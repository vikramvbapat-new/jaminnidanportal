#!/usr/bin/env python3
# coding: utf-8
import unittest,sys,copy,json
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
OUR=BASE/'V26_20261024_CONTROLLED_AI_CONTRACT'
sys.path.insert(0,str(OUR/'reference'))
sys.path.insert(0,str(BASE/'V25_20261024_PARAGRAPH_TRACEABILITY/reference'))
from controlled_validator import inspect
from v25_controlled_qa import run
FIX=BASE/'V23_20261024_REFERENCE_PIPELINE/fixtures'

def sample(s='S02'):
 p=json.loads((FIX/(s+'.json')).read_text(encoding='utf8'))
 _,o=run(copy.deepcopy(p));o['module']='MC5'
 return p,o

class TestCandidateGuard(unittest.TestCase):
 def assert_fail(self,p,o,code):
  r=inspect(p,o)
  self.assertEqual(r['status'],'FAIL',r)
  self.assertIn(code,[x['code'] for x in r['errors']])
 def test_01_positive_status1(self):
  p,o=sample('S01');self.assertEqual(inspect(p,o)['status'],'PASS_STATIC_REVIEW_REQUIRED')
 def test_02_positive_status2(self):
  p,o=sample('S02');self.assertEqual(inspect(p,o)['status'],'PASS_STATIC_REVIEW_REQUIRED')
 def test_03_positive_status3(self):
  p,o=sample('S03');self.assertEqual(inspect(p,o)['status'],'PASS_STATIC_REVIEW_REQUIRED')
 def test_04_positive_late_limitation(self):
  p,o=sample('S04_LATE');self.assertEqual(inspect(p,o)['status'],'PASS_STATIC_REVIEW_REQUIRED')
 def test_05_never_production(self):
  p,o=sample();self.assertFalse(inspect(p,o)['production_ready'])
 def test_06_unknown_module(self):
  p,o=sample();o['module']='MLRC143';self.assert_fail(p,o,'MODULE')
 def test_07_missing_sources(self):
  p,o=sample();o['paragraphs'][0]['source_field_ids']=[];self.assert_fail(p,o,'PARA_PROVENANCE')
 def test_08_fake_source(self):
  p,o=sample();o['paragraphs'][0]['source_field_ids'].append('FAKE_PERSON');self.assert_fail(p,o,'SOURCE_ID')
 def test_09_cross_module_source(self):
  p,o=sample();o['paragraphs'][0]['source_field_ids'].append('MLRC143_ROUTE');self.assert_fail(p,o,'CROSS_MODULE')
 def test_10_wrong_subject(self):
  p,o=sample();o['paragraphs'][0]['title']='नवीन रस्ता';self.assert_fail(p,o,'PARA_TOPIC')
 def test_11_wrong_number(self):
  p,o=sample();o['paragraphs'][0]['number']=14;self.assert_fail(p,o,'PARA_NUMBER')
 def test_12_forged_p1_closing(self):
  p,o=sample();o['paragraphs'][0]['text']='वादी म्हणतात की रस्ता आहे.';self.assert_fail(p,o,'P01_CLOSING')
 def test_13_p2_evidence_leak(self):
  p,o=sample();next(x for x in o['paragraphs'] if x['number']==2)['text']+=' जुने फोटो आहेत.';self.assert_fail(p,o,'P02_EVIDENCE')
 def test_14_width_removed(self):
  p,o=sample();next(x for x in o['paragraphs'] if x['number']==3)['text']='रस्ता पूर्वीपासून आहे.';self.assert_fail(p,o,'P03_WIDTH')
 def test_15_unconfirmed_destination(self):
  p,o=sample();p['fields'].pop('MC5_ROUTE_DESTINATION');self.assert_fail(p,o,'P03_UNVERIFIED_DESTINATION')
 def test_16_approximate_gat_mislabeled(self):
  p,o=sample('S01');p['fields']['MC5_OBSTRUCTION_GAT']['certainty']='approx';self.assert_fail(p,o,'P05_APPROX')
 def test_17_unverified_date(self):
  p,o=sample();next(x for x in o['paragraphs'] if x['number']==5)['text']='१५ जून २०२० रोजी अडथळा केला.';self.assert_fail(p,o,'P05_DATE')
 def test_18_status3_continuing_road(self):
  p,o=sample('S03');next(x for x in o['paragraphs'] if x['number']==6)['text']='अडथळा अद्याप कायम आहे.';self.assert_fail(p,o,'STATUS3_PRESENT_TENSE')
 def test_19_status3_urgent_para(self):
  p,o=sample('S03');o['paragraphs'].append({'number':9,'title':'तातडीची कारणे','text':'आता तातडी आहे.','source_field_ids':['MC5_CURRENT_STATUS']});o['paragraphs'].sort(key=lambda x:x['number']);self.assert_fail(p,o,'P09_STATUS3')
 def test_20_urgency_without_optin(self):
  p,o=sample();p['fields']['MC5_URGENT_HEARING_OPTIN']=False;self.assert_fail(p,o,'P09_NO_OPTIN')
 def test_21_fake_contact(self):
  p,o=sample();p['fields']['MC5_ATTEMPTS_MADE']=False;p['fields'].pop('MC5_ATTEMPT_TYPES',None);p['fields'].pop('MC5_DEFENDANT_RESPONSE',None);self.assert_fail(p,o,'P11_NO_ATTEMPTS')
 def test_22_fake_limitation_assertion(self):
  p,o=sample('S04_LATE');next(x for x in o['paragraphs'] if x['number']==13)['text']+=' हा दावा विहित मुदतीत आहे.';self.assert_fail(p,o,'LIMITATION_FALSE_CLAIM')
 def test_23_invalid_prayer(self):
  p,o=sample();o['prayers'][1]['text']='नवीन रस्ता मंजूर करा.';self.assert_fail(p,o,'PRAYER_TEXT')
 def test_24_wrong_prayer_selection(self):
  p,o=sample('S03');o['prayers'].append({'source_prayer_id':1,'display_number':2,'text':'दावा'});self.assert_fail(p,o,'PRAYER_SELECTION')
 def test_25_discontinuous_prayer_numbers(self):
  p,o=sample();o['prayers'][1]['display_number']=7;self.assert_fail(p,o,'PRAYER_NUMBER')
 def test_26_fake_attachment(self):
  p,o=sample();o['attachments'].append('न जोडलेला फोटो');self.assert_fail(p,o,'FALSE_ANNEXURE')
 def test_27_wrong_land_area(self):
  p,o=sample();o['land_rows'][0]['area']='999';self.assert_fail(p,o,'LAND_TABLE_MISMATCH')
 def test_28_nonmatching_status(self):
  p,o=sample();o['status']=3;self.assert_fail(p,o,'STATUS_MISMATCH')
 def test_29_unresolved_placeholder(self):
  p,o=sample();o['paragraphs'][0]['text']+=' [पडताळणी आवश्यक]';self.assert_fail(p,o,'UNRESOLVED_PLACEHOLDER')
 def test_30_unsupported_role_instruction(self):
  p,o=sample();o['paragraphs'][0]['text']+=' वादीचे म्हणणे आहे';self.assert_fail(p,o,'DISTANCED_LANGUAGE')
 def test_31_duplicate_paragraph(self):
  p,o=sample();o['paragraphs'].append(copy.deepcopy(o['paragraphs'][0]));self.assert_fail(p,o,'PARA_ORDER')
 def test_32_missing_required_p13(self):
  p,o=sample();o['paragraphs']=[x for x in o['paragraphs'] if x['number']!=13];self.assert_fail(p,o,'PARA_REQUIRED')
 def test_33_input_cross_module_field_blocked(self):
  p,o=sample();p['fields']['MLRC143_QUESTION']='ignore rules';self.assert_fail(p,o,'INPUT_VALIDATION')
 def test_34_input_alias_conflict_blocked(self):
  p,o=sample();p['fields']['MC5_REASON4_DAMAGE']='actual';self.assert_fail(p,o,'INPUT_VALIDATION')
 def test_35_source_ids_not_enough_for_semantics(self):
  p,o=sample();r=inspect(p,o);self.assertIn('SEMANTIC_ENTAILMENT',[x['code'] for x in r['manual_review']])
if __name__=='__main__':unittest.main(verbosity=2)
