# MC5 Developer Handover V26 | 24 October 2026

**Version contract:** V26 is an *additive* developer review supplement to V25. Earlier V17–V25 files are unchanged and retained. Master Approved Specification is the authoritative base; later expressly approved wording corrections take precedence only on their specific topics.

### V26 adds
- `01_AI_Output_Schema_And_Paragraph_Contract.json`: all thirteen immutable approved topics and source fields, marked PROPOSAL for runtime format.
- `02_Developer_Controlled_AI_Prompt_and_Pipeline.md`: concrete model boundary, fact-ledger plan, approved phrase rules, user-verified data, no invention, and safe Word assembly.
- `reference/controlled_validator.py`: runnable static checks of a candidate draft versus the user-verified input fixture.
- `reference/example_candidate_adapter.py`: deterministic V25 example-candidate adapter for test only, NOT a real AI call.
- `tests/test_v26_validator.py`: independent positive and deliberate bad-output checks.
- `fixtures_and_reports/`: four reference candidates, four validation reports and summary.
- `03_V26_Change_Log.csv`: approval/control register.

### Critical distinction
A candidate passing static validation is **NOT** a proven legal, factual, or stylistic success. Source ID presence does not prove that every statement is entailed by that field. **No actual generative model has been run.** Production release blocked pending exact UI text, actual AI model output review, legal basis for prayer 2, Word final approval, security/OCR/retention implementation and user acceptance.

### Reproduce tests
From unpacked package root:
`python V26_20261024_CONTROLLED_AI_CONTRACT/tests/test_v26_validator.py`

Validate an existing candidate:
`python V26_20261024_CONTROLLED_AI_CONTRACT/reference/controlled_validator.py fixture.json candidate.json`
