#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V26 controlled draft output QA validator. Static checks only, not a legal or factual truth oracle.
Dependencies: stdlib and retained V23–V25 references. No remote AI API calls.
Use: python controlled_validator.py fixture.json candidate.json
"""
import re,json,sys
from datetime import date
from pathlib import Path
from dateutil.relativedelta import relativedelta
BASE=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(BASE/'V23_20261024_REFERENCE_PIPELINE/reference'),str(BASE/'V24_20261024_FIELD_INTEGRATION/reference'),str(BASE/'V25_20261024_PARAGRAPH_TRACEABILITY/reference')]
import mc5_reference as m
from v24_field_bridge import normalize,BridgeError

REQUIRED={1,2,3,5,6,12,13}
ALL=set(range(1,14))
P1_CLOSING='याच रस्त्यावरील अडथळा हा प्रस्तुत दाव्याचा विषय आहे.'
TOPICS=m.TITLES
NO_LIVE_AI=True


def inspect(payload, candidate):
    errors=[];notes=[];manual=[]
    def err(code,why):errors.append({'code':code,'detail':why})
    def note(code,why):notes.append({'code':code,'detail':why})
    def human(code,why):manual.append({'code':code,'detail':why})
    if not isinstance(candidate,dict):
        return {'status':'FAIL','errors':[{'code':'SCHEMA','detail':'Output must be JSON object'}],'warnings':[],'manual_review':[],'production_ready':False}
    try:
        normalized,aliases=normalize(payload)
        m.validate(normalized)
    except (ValueError,KeyError,TypeError) as ex:
        err('INPUT_VALIDATION',str(ex));normalized=None
    if not normalized:
        return {'status':'FAIL','errors':errors,'warnings':notes,'manual_review':manual,'production_ready':False}
    f=normalized['fields']; status=f['MC5_CURRENT_STATUS']
    if candidate.get('module')!='MC5':err('MODULE','Only §5 MC5 module accepted')
    p=candidate.get('paragraphs')
    if not isinstance(p,list):err('PARAGRAPHS_SCHEMA','Missing paragraphs array');p=[]
    nums=[];fkeys=set(f)
    for x in p:
        if not isinstance(x,dict):err('PARA_OBJECT','Each paragraph must be JSON object');continue
        n=x.get('number');nums.append(n)
        if type(n)!=int or n not in ALL:err('PARA_NUMBER','Paragraph number outside immutable 1–13: '+str(n));continue
        if x.get('title')!=TOPICS[n]:err('PARA_TOPIC',f'P{n:02d} topic changed')
        s=x.get('text')
        if not isinstance(s,str) or not s.strip():err('PARA_TEXT',f'P{n:02d} missing content');continue
        ids=x.get('source_field_ids')
        if not isinstance(ids,list) or not ids:err('PARA_PROVENANCE',f'P{n:02d} missing source field IDs')
        else:
            if any(not isinstance(id,str) or (id not in fkeys) for id in ids):err('SOURCE_ID',f'P{n:02d} references unknown or unprovided source ID')
            if any(id.startswith('MLRC143') for id in ids):err('CROSS_MODULE',f'P{n:02d} carries §143 source')
        if any(t in s for t in ['[पडताळणी आवश्यक]','[प्रश्नावली','[अंतर्गत AI','{{','}}']):err('UNRESOLVED_PLACEHOLDER',f'P{n:02d} contains unresolved template text')
        if 'वादीचे म्हणणे आहे' in s:err('DISTANCED_LANGUAGE',f'P{n:02d} has forbidden third-person formula')
        if '\n' in s and s.count('\n')>3:note('PARA_LONG',f'P{n:02d} contains unexpected newlines; inspect layout')
        if n==2 and any(w in s for w in ['जुने फोटो','साक्षीदार','महसूल/न्यायालयीन आदेश','नोंदणीकृत दस्त','पुरावे उपलब्ध']):err('P02_EVIDENCE', 'P02 must describe historical road usage, not list evidence')
    if nums!=sorted(nums) or len(nums)!=len(set(nums)):err('PARA_ORDER','Fixed paragraph IDs out-of-order or duplicate')
    if not REQUIRED.issubset(set(nums)):err('PARA_REQUIRED','Required paragraphs absent: '+str(sorted(REQUIRED-set(nums))))
    d={r['number']:r for r in p if isinstance(r,dict) and type(r.get('number'))==int}
    if 1 in d and not d[1].get('text','').strip().endswith(P1_CLOSING):err('P01_CLOSING','Exact approved P01 closing sentence missing')
    if 3 in d:
        text=d[3].get('text','')
        width=str(f['MC5_ROAD_WIDTH_FT'])
        if not re.search(r'(?<!\d)'+re.escape(width)+r'\s*फूट',text):err('P03_WIDTH','Verified approximate average width not correctly shown')
        if 'गाव रस्त्यापर्यंत' in text and f.get('MC5_ROUTE_DESTINATION')!='गाव रस्ता':err('P03_UNVERIFIED_DESTINATION','Village road connection not verified')
        if 'अंदाजे लांबी' in text and not f.get('MC5_ROAD_LENGTH_FT'):err('P03_UNVERIFIED_LENGTH','Optional length not provided')
        if 'गट क्रमांक' not in text and 'मार्गाने' not in text:note('P03_ROUTE','Route phrasing needs human review')
    if 5 in d:
        txt=d[5].get('text','')
        if m.fmt_date(f['MC5_OBSTRUCTION_DATE']) not in txt:err('P05_DATE','P05 must use current actionable obstruction date')
        if f['MC5_OBSTRUCTION_GAT']['certainty']=='approx' and 'अंदाजे गट क्रमांक' not in txt:err('P05_APPROX','Approximate obstruction gat must not be stated as exact')
    if status==3:
        if 9 in d:err('P09_STATUS3','Present-tense urgency disallowed for fully removed physical obstruction')
        for n in [6,7,8]:
            if n in d and any(w in d[n].get('text','') for w in ['अडथळा अद्याप कायम आहे','रस्ता सध्या बंद आहे','अजूनही अडचण आहे']):err('STATUS3_PRESENT_TENSE',f'P{n:02d} implies continuing physical obstruction')
    if (not f.get('MC5_ATTEMPTS_MADE')) and 11 in d:err('P11_NO_ATTEMPTS','Cannot invent prior attempts')
    if 9 in d and not (status in (1,2) and f.get('MC5_URGENCY_REASONS') and f.get('MC5_URGENT_HEARING_OPTIN')):
        err('P09_NO_OPTIN','Urgency paragraph requires confirmed facts and explicit hearing opt-in in V25 reference contract')
    if 12 in d and 'दाव्यास कारण' != d[12].get('title'):err('P12_HEADING','P12 heading fixed')
    if 13 in d:
        o=date.fromisoformat(f['MC5_OBSTRUCTION_DATE']);filing=date.fromisoformat(f['MC5_FILING_DATE'])
        if filing>=o+relativedelta(months=6) and 'विहित मुदतीत' in d[13].get('text',''):err('LIMITATION_FALSE_CLAIM','Never assert within limit for boundary/late filing')
        if filing<o+relativedelta(months=6) and (o+relativedelta(months=6)-filing).days<=30:note('LIMITATION_NEAR','Limit date approaching; requires legal date review')
    prayers=candidate.get('prayers')
    if not isinstance(prayers,list):err('PRAYERS_SCHEMA','Prayers array required');prayers=[]
    ids=[r.get('source_prayer_id') for r in prayers if isinstance(r,dict)]
    expected=[1,2,3] if status in (1,2) else [3]
    if status in (1,2) and f.get('MC5_URGENCY_REASONS') and f.get('MC5_URGENT_HEARING_OPTIN'):expected.append(4)
    if ids!=expected:err('PRAYER_SELECTION',f'Prayers {ids} differ from required {expected}')
    for n,r in enumerate(prayers,1):
        if not isinstance(r,dict):err('PRAYER_SCHEMA','Prayer entry must be object');continue
        if r.get('display_number')!=n:err('PRAYER_NUMBER','Displayed prayer numbers must be consecutive')
        if r.get('source_prayer_id') not in m.PRAYERS or r.get('text')!=m.PRAYERS.get(r.get('source_prayer_id')):
            err('PRAYER_TEXT','Prayer language must match approved Master exactly')
    declared=candidate.get('attachments')
    attached=[r['label'] for r in payload.get('attached_documents',[]) if r.get('actually_attached') is True]
    if declared!=attached:err('FALSE_ANNEXURE','Only explicitly attached documents may appear in annexure list')
    if candidate.get('status') != status:err('STATUS_MISMATCH','Output status differs from verified user input')
    if candidate.get('land_rows') is None:err('LAND_TABLE_MISSING','Approved five-column land table data missing')
    else:
        expectedrows=[m.area_for(r) for r in f['MC5_LAND_RECORDS']]
        if candidate['land_rows']!=expectedrows:err('LAND_TABLE_MISMATCH','Land row source data modified or omitted')
    # Automated checks alone cannot prove semantic faithfulness of prose.
    human('SEMANTIC_ENTAILMENT','Check every drafted factual clause against original verified answer; source IDs alone do not prove truth')
    human('LANGUAGE_QUALITY','Review idiomatic Marathi pleading, nonrepetition and legal phrasing in actual AI output')
    human('UNAPPROVED_SCREEN_TEXT','Final question wording and S7 six urgency options still require approved source reconciliation')
    human('PRAYER_2_LEGAL_BASIS','Master flags prayer 2 implementation legal basis for final checking')
    human('DOCX_VISUAL_QA','Inspect rendered Word pages for multiparty, multiple gats, large content and signature layout')
    result={'status':'FAIL' if errors else 'PASS_STATIC_REVIEW_REQUIRED','errors':errors,'warnings':notes,'manual_review':human and manual,'production_ready':False,'paragraph_count':len(p),'checked_source_fields':len(fkeys)}
    return result

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: controlled_validator.py fixture.json draft_candidate.json')
    payload=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    candidate=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
    result=inspect(payload,candidate)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['status']!='FAIL' else 2)
