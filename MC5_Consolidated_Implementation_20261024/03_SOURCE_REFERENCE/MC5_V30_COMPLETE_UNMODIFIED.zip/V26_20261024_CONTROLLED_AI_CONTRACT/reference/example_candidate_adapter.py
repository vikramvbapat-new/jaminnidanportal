#!/usr/bin/env python3
# coding: utf-8
"""Create a candidate JSON from V25 deterministic fixture runner (NOT from an AI model)."""
import json,sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'V25_20261024_PARAGRAPH_TRACEABILITY/reference'))
from v25_controlled_qa import run
if __name__=='__main__':
    payload=json.loads(Path(sys.argv[1]).read_text(encoding='utf8'))
    _,out=run(payload)
    out['module']='MC5';out['source_master_version']='2026-10-23';out['candidate_mode']='V25_DETERMINISTIC_FIXTURE_NOT_AI'
    Path(sys.argv[2]).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
