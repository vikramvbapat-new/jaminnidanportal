# जमीन निदान पोर्टल V2 — कलम ५ — Developer Handover V24

**दिनांक:** २४ ऑक्टोबर २०२६  
**स्थिती:** QA/reference implementation. **Not production ready / not an approved court petition.**

## महत्त्वाच्या स्रोतांची प्राधान्य श्रेणी
1. मंजूर Master Base Application, Master Change Register V17 आणि २३ ऑक्टोबरचा Master Approved Specification.
2. वापरकर्त्याने त्यानंतर **२४ ऑक्टोबर रोजी मंजूर केलेल्या** मर्यादित दुरुस्त्या (V18 Addendum).
3. V17 मधील प्रश्नावली/Field IDs आणि V16 Inventory (जिथे *candidate* शब्दांकन आहे तिथे अंतिम मानू नये).
4. V23/V24 QA fixtures आणि deterministic reference renderer — व्यवहार्य उदाहरणे, **अंतिम मंजूर मसुदा नाहीत**.

## V24 मधील प्रत्यक्ष नवे काम
- `01_All_47_Field_Source_Routing.csv` — ४७ फील्डसाठी V16 स्क्रीन स्थान, V17 Crosswalk, मूळ field ID, प्रस्तावित canonical alias, अंतिम/प्रस्तावित UI text status.
- `02_Proposed_Alias_Map.json` — सात संभाव्य duplicate field जोडी; **renaming मंजूर नाही**. जुन्या-नव्या नावांनी भिन्न मूल्ये आल्यास explicit error.
- `reference/v24_field_bridge.py` — V17 field identifiers स्वीकारून V23 संदर्भ-लेखनप्रणालीला adapters; प्रणालीचे अज्ञात/कलम १४३ identifiers reject.
- `reference/v24_lifecycle.py` — Save Draft संपादल्यानंतर संमती reset, conditional values clear, Word serial/revision/30-days expiry यांचे *pure in-memory model*.
- `reference/run_v24.py` — संरचित JSON वरून Word व paragraph trace तयार करणारा QA-only runner.
- `reference/test_v24.py` — ३५ स्वयंचलित चाचण्या; V23 मधील १७ regression चाचण्याही पुन्हा चालवल्या.
- `output_examples/` — चार synthetic न्यायालयीन नमुने (Word) व paragraph traces; न्यायालयात दाखल करू नयेत.
- `rendered_S02/` — वाचनयोग्य दृश्य नमुना पाहण्यासाठी internal QA पानरेंडर (production layout मंजूर नाही).
- `06_V24_Quality_and_Release_Report.json` — अचूक स्थिती व release blockers.

## पुनरुत्पादन
ZIP मूळ directory structure सह extract केल्यानंतर:
```bash
cd V24_20261024_FIELD_INTEGRATION/reference
python test_v24.py
python run_v24.py ../../V23_20261024_REFERENCE_PIPELINE/fixtures/S02.json ../output_examples
```

**Reference program मध्ये खरा AI model नाही.** नियंत्रित AI साठी अंतिम मंजूर प्रश्नांचे शब्दांकन, परिच्छेदनिहाय source tracking, schema approval, security आणि live QA अजून आवश्यक आहेत.

## बदल नियंत्रण
- १३ परिच्छेदांचे विषय/क्रमांक आणि अंतिम मागण्यांचा मंजूर आशय बदललेला नाही.
- Original V17/V18/V19/V20/V21/V22/V23 files retained.
- V24 मधील सात alias जोडी व S7 प्रश्न शब्दांकन मंजुरीशिवाय final करू नये.

## प्रामाणिक QA नोंद
V22 च्या मागील उत्तरात `20/20` म्हटले गेले, पण रेकॉर्डमधील raw static run मध्ये whitespace न trim केल्याने १ चाचणी FAIL झाली होती. त्यावेळचा प्रत्यक्ष निकाल 19/20; V24 मध्ये whitespace-trim करून V17 field links सर्व वैध असल्याचे पुन्हा पडताळले आहे. V24 35/35 आणि V23 regression 17/17 हे वेगळे ताजे निकाल आहेत.
