#!/usr/bin/env python3
"""Pure QA reference for approved consent-reset and Word-number lifecycle semantics.
No actual account/session/store, allocation provider, timer, retention job or OTP.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json, copy

class LifecycleError(ValueError):pass

@dataclass
class Draft:
    started_at:datetime
    facts:dict=field(default_factory=dict)
    consent:bool=False
    app_number:str|None=None
    word_revision:int=0
    previous_export_hash:str|None=None

    def edit(self,changes:dict):
        # idempotent/no-op edits must not falsely reset user consent.
        material={k:v for k,v in changes.items() if self.facts.get(k)!=v}
        if not material:return False
        self.facts.update(copy.deepcopy(material))
        self.consent=False
        # dependent fields hidden after status/attempt/urgency changes are stale.
        if self.facts.get('MC5_ATTEMPTS_MADE') is False:
            self.facts.pop('MC5_ATTEMPT_TYPES',None)
            self.facts.pop('MC5_DEFENDANT_RESPONSE',None)
        if self.facts.get('MC5_CURRENT_STATUS')==3:
            for k in ('MC5_URGENCY_REASONS','MC5_URGENT_HEARING','MC5_URGENT_HEARING_OPTIN','MC5_REASON3_DETAILS','MC5_URGENCY_3_SUBOPTIONS','MC5_REASON4_DAMAGE','MC5_URGENCY_4_DAMAGE_STATUS','MC5_REASON5_HOUSE','MC5_FARM_HOUSE_CONFIRMED'):
                self.facts.pop(k,None)
        reasons=self.facts.get('MC5_URGENCY_REASONS') or []
        if 3 not in reasons:
            self.facts.pop('MC5_REASON3_DETAILS',None)
            self.facts.pop('MC5_URGENCY_3_SUBOPTIONS',None)
        if 4 not in reasons:
            self.facts.pop('MC5_REASON4_DAMAGE',None)
            self.facts.pop('MC5_URGENCY_4_DAMAGE_STATUS',None)
        if 5 not in reasons:
            self.facts.pop('MC5_REASON5_HOUSE',None)
            self.facts.pop('MC5_FARM_HOUSE_CONFIRMED',None)
        if not reasons:
            self.facts.pop('MC5_URGENT_HEARING',None)
            self.facts.pop('MC5_URGENT_HEARING_OPTIN',None)
        return True

    def approve(self):self.consent=True

    def successful_word(self,validated_export_payload:dict, serial_from_allocator:str|None=None):
        """Called only after successful, approved generation. Hash semantic export payload.
        For real production serial_from_allocator MUST come from atomic server allocator.
        """
        if not self.consent:raise LifecycleError('User consent required after facts change')
        h=sha256(json.dumps(validated_export_payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        if self.app_number is None:
            if not serial_from_allocator:raise LifecycleError('Unique non-reused serial from server allocator required')
            self.app_number=serial_from_allocator
            self.word_revision=1
            self.previous_export_hash=h
            return {'status':'first export','number':self.app_number,'revision':self.word_revision}
        if serial_from_allocator and serial_from_allocator!=self.app_number:raise LifecycleError('Cannot reuse a new app serial on revision')
        if h!=self.previous_export_hash:
            self.word_revision+=1;self.previous_export_hash=h
            return {'status':'changed export','number':self.app_number,'revision':self.word_revision}
        return {'status':'identical export','number':self.app_number,'revision':self.word_revision}

    def expired(self,now:datetime)->bool:
        if self.started_at.tzinfo is None or now.tzinfo is None:raise LifecycleError('Timezone-aware timestamps required')
        return now >= self.started_at + timedelta(days=30)
