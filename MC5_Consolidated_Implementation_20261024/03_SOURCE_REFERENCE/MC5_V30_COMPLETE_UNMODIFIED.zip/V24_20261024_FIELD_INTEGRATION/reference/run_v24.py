#!/usr/bin/env python3
# coding: utf-8
"""QA-only source bridged executable path: V17 field IDs -> V23 renderer."""
import sys, json, copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'V23_20261024_REFERENCE_PIPELINE/reference'))
from v24_field_bridge import normalize,visibility_and_validation_rules,BridgeError,FIELD_IDS,ALIAS_MAP
from mc5_reference import compose,write_docx

def run(source:Path, output_dir:Path)->dict:
    data=json.loads(source.read_text(encoding='utf-8'))
    fields=data['fields']
    normalized,report=normalize(data)
    screen=visibility_and_validation_rules(normalized['fields'])
    if screen['errors']:raise BridgeError('; '.join(screen['errors']))
    # Guard against JSON 'uploaded_docs' being used to attach actual files, since the
    # approved Master distinguishes checked enclosures from file uploads. This field
    # is a legacy candidate and requires reconciliation, not an approved upload UI.
    if normalized['fields'].get('MC5_UPLOADED_DOCS'):
        raise BridgeError('MC5_UPLOADED_DOCS is not an approved evidence-file upload path; use confirmed attachment checklist')
    assembled=compose(normalized)
    output_dir.mkdir(parents=True,exist_ok=True)
    word=output_dir/(source.stem+'_V24_Word_REVIEW.docx')
    trace=output_dir/(source.stem+'_V24_trace.json')
    write_docx(normalized,assembled,word)
    trace.write_text(json.dumps({'source':source.name,'field_bridge':report,'conditional_visibility':screen,
        'output':assembled,'outcome':'QA-only; no AI, OCR, OTP or production persistence'},ensure_ascii=False,indent=2),encoding='utf-8')
    return {'fixture':source.name,'docx':word.name,'trace':trace.name,'paragraph_count':len(assembled['paragraphs']),
            'prayers':[r['source_prayer_id'] for r in assembled['prayers']],
            'warnings':assembled['warnings'],'alias_conversions':len(report['normalized_aliases'])}

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: python run_v24.py INPUT_JSON OUTPUT_DIRECTORY')
    print(json.dumps(run(Path(sys.argv[1]),Path(sys.argv[2])),ensure_ascii=False,indent=2))
