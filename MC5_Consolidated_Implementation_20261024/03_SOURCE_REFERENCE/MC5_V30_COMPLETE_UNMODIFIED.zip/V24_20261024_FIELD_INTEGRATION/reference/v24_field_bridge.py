#!/usr/bin/env python3
# coding: utf-8
"""V24 source-preserving QA integration bridge.

Not an approved UI schema, AI engine, OTP, OCR, billing or deployed application.
Uses the 47 IDs as supplied; canonical aliases are *proposal*, not approval.
"""
from __future__ import annotations
import copy, csv, json
from pathlib import Path
from dataclasses import dataclass
from typing import Any

SOURCE_FIELDS = Path(__file__).resolve().parents[2] / '01_Field_Dictionary.csv'
SOURCE_INVENTORY = Path(__file__).resolve().parents[2] / '40_V16_Questionnaire_Field_Inventory.csv'
SOURCE_CANON = Path(__file__).resolve().parents[2] / '42_V17_Field_Canonicalization.csv'
SOURCE_CROSSWALK = Path(__file__).resolve().parents[2] / '43_V17_Questionnaire_Crosswalk.csv'

class BridgeError(ValueError):pass


def read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f:return list(csv.DictReader(f))

DICT = read_csv(SOURCE_FIELDS)
INV = {r['Field ID']:r for r in read_csv(SOURCE_INVENTORY)}
CAN = {r['Existing Field ID']:r for r in read_csv(SOURCE_CANON)}
FIELD_IDS = {r['Field ID'] for r in DICT}
ALIAS_MAP = {r['Existing Field ID']:r['Canonical Field ID (proposed)']
             for r in CAN.values() if r['Disposition'].startswith('Proposed alias')}
# These are explicitly fixture-only support values in V23, not V17-approved user questions.
AUXILIARY_QA_FIELDS = {'MC5_ROUTE_DESTINATION','MC5_CONCRETE_DIFFICULTY'}

SYSTEM_FIELDS = {'MC5_DRAFT_ID','MC5_STARTED_AT','MC5_APP_NUMBER','MC5_WORD_REVISION','MC5_APP_SERIAL'}
REG_FIELDS = {'ACCOUNT_NAME','ACCOUNT_PHONE','ACCOUNT_TYPE','ACCOUNT_CENTER','WHATSAPP_OPTIN'}


def normalize(payload:dict, *, allow_qa_extensions:bool=True)->tuple[dict,dict]:
    """Create an alias-resolved *copy* for V23 runner; never overwrite originals.

    Conflict is an error, incl. False vs True; None/empty string is treated as a
    supplied value, not implicitly overwritten. Alias duplicates have one output.
    """
    if not isinstance(payload,dict) or not isinstance(payload.get('fields'),dict):
        raise BridgeError('Expected JSON object with fields object')
    fields=payload['fields']
    unknown=set(fields)-FIELD_IDS
    if allow_qa_extensions:unknown -= AUXILIARY_QA_FIELDS
    if unknown:raise BridgeError('Unknown fields: '+', '.join(sorted(unknown)))
    normalized=copy.deepcopy(payload)
    merged=normalized['fields']; resolved=[]
    for old, canonical in ALIAS_MAP.items():
        oldpresent=old in merged;newpresent=canonical in merged
        if oldpresent and newpresent and merged[old]!=merged[canonical]:
            raise BridgeError(f'Conflicting proposed aliases: {old} and {canonical}')
        if oldpresent:
            if not newpresent:merged[canonical]=copy.deepcopy(merged[old])
            del merged[old]
            resolved.append({'source':old,'canonical_proposed':canonical,'duplicated_equal':newpresent})
    # V23 runner expects the alias names; adapt back only in an ephemeral execution copy.
    runner=copy.deepcopy(normalized)
    for old,canonical in ALIAS_MAP.items():
        if canonical in runner['fields'] and old in { 'MC5_HARVESTED_STOCK','MC5_FARM_HOUSE_CONFIRMED','MC5_URGENCY_3_SUBOPTIONS','MC5_URGENCY_4_DAMAGE_STATUS','MC5_URGENT_HEARING_OPTIN','MC5_FINAL_CONSENT','MC5_APP_SERIAL'}:
            runner['fields'][old]=copy.deepcopy(runner['fields'][canonical])
    return runner,{'input_ids':sorted(fields),'normalized_aliases':resolved,'unknown_rejected':True,
                   'bridge_status':'QA adaptation; V17 alias approval pending'}


def route_rows()->list[dict]:
    crosswalk=read_csv(SOURCE_CROSSWALK)
    cross={}
    for r in crosswalk:
        for fid in r['Field IDs'].split(';'):cross.setdefault(fid.strip(),[]).append(r['Screen'])
    output=[]
    for r in DICT:
        fid=r['Field ID']; record=INV[fid];canon=CAN[fid]
        step=record['Screen']
        if fid in REG_FIELDS:kind='account/non-petition'
        elif fid in SYSTEM_FIELDS:kind='internal lifecycle/non-question'
        elif canon['Disposition'].startswith('Proposed alias'):kind='proposed alias / no duplicate question'
        else:kind='petition data or review control'
        if fid in cross:route='V17 explicit crosswalk'
        elif record['Screen']:route='V16 inventory screen only (not V17 crosswalk)'
        else:route='missing source route'
        wording=record['Wording status']
        output.append({'field_id':fid,'source_screen':step,'v17_explicit_crosswalk':'; '.join(cross.get(fid,[])),
                       'routing_evidence':route,'kind':kind,
                       'canonical_proposed':canon['Canonical Field ID (proposed)'],
                       'alias_approval':canon['Approval Status'],
                       'question_text_verbatim':record['Question / approved option text'],
                       'wording_status':wording,
                       'requires_question_copy_approval':kind=='petition data or review control' and 'मंजूर शब्दांकन' not in wording,
                       'not_new_input_when_alias':kind.startswith('proposed alias')})
    return output


def visibility_and_validation_rules(f:dict)->dict:
    """Approved substantive conditional logic, not user-facing string copy."""
    status=f.get('MC5_CURRENT_STATUS')
    crop=f.get('MC5_CROP_STATUS')
    attempts=f.get('MC5_ATTEMPTS_MADE')
    reasons=f.get('MC5_URGENCY_REASONS') or []
    result={
        'MC5_ATTEMPT_TYPES':attempts is True,
        'MC5_DEFENDANT_RESPONSE':attempts is True,
        'MC5_HARVESTED_PRODUCE':crop in ('not_grown','no_current_planned'),
        'MC5_REASON3_DETAILS':status in (1,2) and 3 in reasons,
        'MC5_REASON4_DAMAGE':status in (1,2) and 4 in reasons,
        'MC5_REASON5_HOUSE':status in (1,2) and 5 in reasons,
        'MC5_URGENT_HEARING':status in (1,2) and bool(reasons),
        'MC5_URGENCY_REASONS':status in (1,2),
    }
    errors=[];warnings=[]
    if attempts is False and (f.get('MC5_ATTEMPT_TYPES') or f.get('MC5_DEFENDANT_RESPONSE')):
        errors.append('S6 hidden attempted-contact values must be cleared')
    if status==3 and (reasons or f.get('MC5_URGENT_HEARING') or f.get('MC5_URGENT_HEARING_OPTIN')):
        errors.append('S7/S9 urgency not applicable to status 3')
    if 3 in reasons and not(f.get('MC5_REASON3_DETAILS') or f.get('MC5_URGENCY_3_SUBOPTIONS')):
        errors.append('Reason 3 requires one or more confirmed subchoices')
    if 4 in reasons and f.get('MC5_REASON4_DAMAGE') is None and f.get('MC5_URGENCY_4_DAMAGE_STATUS') is None:
        errors.append('Reason 4 must distinguish actual loss vs risk')
    if 5 in reasons and not (f.get('MC5_REASON5_HOUSE') is True or f.get('MC5_FARM_HOUSE_CONFIRMED') is True):
        errors.append('Reason 5 requires explicit farm house confirmation')
    if 6 in reasons: warnings.append('Reason 6 has no subquestion (V17 approved logic)')
    return {'visible':result,'errors':errors,'warnings':warnings}


def make_artifacts(outdir:Path):
    outdir.mkdir(parents=True,exist_ok=True)
    rows=route_rows()
    with (outdir/'01_All_47_Field_Source_Routing.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (outdir/'02_Proposed_Alias_Map.json').write_text(json.dumps(ALIAS_MAP,ensure_ascii=False,indent=2),encoding='utf-8')
    info={'field_count':len(rows),'v17_crosswalked':sum(bool(r['v17_explicit_crosswalk']) for r in rows),
          'v16_screen_covered':sum(bool(r['source_screen']) for r in rows),
          'proposed_alias_fields':sum(r['not_new_input_when_alias'] for r in rows),
          'requires_ui_text_approval':sum(r['requires_question_copy_approval'] for r in rows),
          'approval_status':'Mapping is traceable, not all UI wording approved'}
    (outdir/'03_Field_Mapping_Statistics.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
    return info

if __name__=='__main__':
    print(json.dumps(make_artifacts(Path(__file__).resolve().parents[1]),ensure_ascii=False,indent=2))
