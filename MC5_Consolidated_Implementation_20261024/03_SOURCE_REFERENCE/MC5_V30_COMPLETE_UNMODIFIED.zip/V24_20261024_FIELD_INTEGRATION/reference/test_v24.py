#!/usr/bin/env python3
import unittest,json,copy,tempfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from v24_field_bridge import FIELD_IDS, ALIAS_MAP,route_rows,normalize,visibility_and_validation_rules,BridgeError
from run_v24 import run
from v24_lifecycle import Draft,LifecycleError
from datetime import datetime,timedelta,timezone
ROOT=Path(__file__).resolve().parents[2]
FIX=ROOT/'V23_20261024_REFERENCE_PIPELINE/fixtures'
def load(name='S01'):
    return json.loads((FIX/(name+'.json')).read_text(encoding='utf-8'))
class FieldBridgeTests(unittest.TestCase):
 def test_source_47(self):self.assertEqual(len(FIELD_IDS),47)
 def test_field_coverage_exact(self):
    self.assertEqual({x['field_id'] for x in route_rows()},FIELD_IDS)
 def test_source_screen_all(self):
    self.assertTrue(all(x['source_screen'] for x in route_rows()))
 def test_crosswalk_20(self):
    self.assertEqual(sum(bool(x['v17_explicit_crosswalk']) for x in route_rows()),20)
 def test_proposed_aliases_7(self):self.assertEqual(len(ALIAS_MAP),7)
 def test_unapproved_alias_not_new_input(self):
    self.assertEqual(sum(x['not_new_input_when_alias'] for x in route_rows()),6)
 def test_normalize_no_mutation(self):
    a=load('S02');before=copy.deepcopy(a);normalize(a);self.assertEqual(a,before)
 def test_normalize_accepted_existing(self):
    a=load('S02');b,r=normalize(a);self.assertEqual(b['fields']['MC5_URGENT_HEARING_OPTIN'],True)
 def test_normalize_alias_canonical_only(self):
    a=load('S02');a['fields']['MC5_URGENT_HEARING']=a['fields'].pop('MC5_URGENT_HEARING_OPTIN')
    b,r=normalize(a);self.assertTrue(b['fields']['MC5_URGENT_HEARING_OPTIN']);self.assertTrue(all(x['source']!='MC5_URGENT_HEARING_OPTIN' for x in r['normalized_aliases']))
 def test_duplicate_equal(self):
    a=load('S02');a['fields']['MC5_URGENT_HEARING']=True
    b,r=normalize(a);self.assertTrue(b['fields']['MC5_URGENT_HEARING_OPTIN'])
 def test_duplicate_conflict(self):
    a=load('S02');a['fields']['MC5_URGENT_HEARING']=False
    with self.assertRaises(BridgeError):normalize(a)
 def test_consent_conflict(self):
    a=load();a['fields']['MC5_FINAL_CONSENT']=False
    with self.assertRaises(BridgeError):normalize(a)
 def test_unknown_field_rejected(self):
    a=load();a['fields']['MC143_APPLICANT']='Wrong module'
    with self.assertRaises(BridgeError):normalize(a)
 def test_qa_auxiliary_supported(self):
    a=load();a['fields']['MC5_ROUTE_DESTINATION']='गाव रस्ता';normalize(a)
 def test_hide_attempts(self):
    a=load();a['fields']['MC5_ATTEMPTS_MADE']=False;a['fields']['MC5_ATTEMPT_TYPES']=[];a['fields']['MC5_DEFENDANT_RESPONSE']=None
    self.assertFalse(visibility_and_validation_rules(a['fields'])['visible']['MC5_ATTEMPT_TYPES'])
 def test_attempt_hidden_data_errors(self):
    a=load();a['fields']['MC5_ATTEMPTS_MADE']=False
    self.assertTrue(visibility_and_validation_rules(a['fields'])['errors'])
 def test_status3_urgency_hidden(self):
    a=load('S03');self.assertFalse(visibility_and_validation_rules(a['fields'])['visible']['MC5_URGENCY_REASONS'])
 def test_status3_stale_urgency_rejected(self):
    a=load('S03');a['fields']['MC5_URGENCY_REASONS']=[2]
    self.assertTrue(visibility_and_validation_rules(a['fields'])['errors'])
 def test_reason3_requires_suboption(self):
    a=load('S01');a['fields']['MC5_URGENCY_REASONS']=[3]
    self.assertTrue(visibility_and_validation_rules(a['fields'])['errors'])
 def test_reason4_damage_distinction(self):
    a=load('S02');a['fields'].pop('MC5_URGENCY_4_DAMAGE_STATUS')
    self.assertTrue(visibility_and_validation_rules(a['fields'])['errors'])
 def test_reason5_house_confirmation(self):
    a=load('S02');a['fields']['MC5_URGENCY_REASONS']=[5]
    self.assertTrue(visibility_and_validation_rules(a['fields'])['errors'])
 def test_reason6_no_subquestion(self):
    a=load('S02');a['fields']['MC5_URGENCY_REASONS']=[6]
    self.assertTrue(visibility_and_validation_rules(a['fields'])['warnings'])
 def test_real_pipeline_3_cases(self):
    with tempfile.TemporaryDirectory() as tmp:
     for case,prayers in [('S01',[1,2,3]),('S02',[1,2,3,4]),('S03',[3])]:
      summary=run(FIX/(case+'.json'),Path(tmp))
      self.assertEqual(summary['prayers'],prayers)
      self.assertTrue((Path(tmp)/summary['docx']).exists())
      self.assertTrue((Path(tmp)/summary['trace']).exists())
 def test_late_case_warns(self):
    with tempfile.TemporaryDirectory() as tmp:self.assertTrue(run(FIX/'S04_LATE.json',Path(tmp))['warnings'])
 def test_evidence_upload_rejected(self):
    a=load();a['fields']['MC5_UPLOADED_DOCS']=['demo.pdf']
    with tempfile.TemporaryDirectory() as tmp:
     p=Path(tmp)/'test.json';p.write_text(json.dumps(a),encoding='utf-8')
     with self.assertRaises(BridgeError):run(p,Path(tmp))
class LifecycleTests(unittest.TestCase):
 def test_edit_resets_consent(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc),facts={'MC5_ROAD_WIDTH_FT':8},consent=True)
    self.assertTrue(d.edit({'MC5_ROAD_WIDTH_FT':9}));self.assertFalse(d.consent)
 def test_noop_keeps_consent(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc),facts={'x':1},consent=True)
    self.assertFalse(d.edit({'x':1}));self.assertTrue(d.consent)
 def test_clear_hidden_attempts(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc),facts={'MC5_ATTEMPTS_MADE':True,'MC5_ATTEMPT_TYPES':[1],'MC5_DEFENDANT_RESPONSE':1})
    d.edit({'MC5_ATTEMPTS_MADE':False});self.assertNotIn('MC5_ATTEMPT_TYPES',d.facts)
 def test_clear_status3_urgency(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc),facts={'MC5_CURRENT_STATUS':2,'MC5_URGENCY_REASONS':[2],'MC5_URGENT_HEARING':True})
    d.edit({'MC5_CURRENT_STATUS':3});self.assertNotIn('MC5_URGENCY_REASONS',d.facts)
 def test_first_serial_allocated_only_after_consent(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc))
    with self.assertRaises(LifecycleError):d.successful_word({'x':1},'MC5-1')
    d.approve();self.assertEqual(d.successful_word({'x':1},'MC5-1')['revision'],1)
 def test_no_new_serial_on_same_content(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc));d.approve()
    d.successful_word({'x':1},'MC5-1')
    self.assertEqual(d.successful_word({'x':1})['revision'],1)
 def test_revision_on_changed_export(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc));d.approve();d.successful_word({'x':1},'MC5-1')
    self.assertEqual(d.successful_word({'x':2})['revision'],2)
 def test_atomic_serial_provider_not_implemented(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc));d.approve()
    with self.assertRaises(LifecycleError):d.successful_word({'x':1})
 def test_no_serial_reassignment(self):
    d=Draft(datetime(2026,10,24,tzinfo=timezone.utc));d.approve();d.successful_word({'x':1},'MC5-1')
    with self.assertRaises(LifecycleError):d.successful_word({'x':2},'MC5-2')
 def test_30_days_immutable(self):
    start=datetime(2026,10,1,tzinfo=timezone.utc);d=Draft(start)
    self.assertFalse(d.expired(start+timedelta(days=29,seconds=86399)))
    self.assertTrue(d.expired(start+timedelta(days=30)))

if __name__=='__main__':unittest.main(verbosity=2)
