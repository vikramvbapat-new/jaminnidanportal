V7 extends V6. Includes source-based A-D audit and findings. NOT final sign-off; original field-value fixtures are missing. Do not use fictional test names or bracket notes in production.
