MC5 Developer Handover V3 — expanded WORKING package, not final sign-off.
Master V17 included for source traceability.
Includes prior V2 docs, expanded field dictionary, 44 acceptance tests, paragraph drafting controls, Word template skeleton.
No code. Missing: verbatim full screen questionnaire and complete language bank confirmation.
