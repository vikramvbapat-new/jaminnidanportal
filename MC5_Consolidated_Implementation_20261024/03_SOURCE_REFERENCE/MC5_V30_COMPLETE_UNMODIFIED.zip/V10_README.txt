V10 adds a deterministic non-production rule reference, 15 executed synthetic tests, and a release gap report. All prior V9 files retained. No claim of end-to-end application generation.
