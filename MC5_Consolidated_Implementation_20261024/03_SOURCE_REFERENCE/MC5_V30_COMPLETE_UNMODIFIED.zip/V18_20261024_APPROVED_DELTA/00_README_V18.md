# MC5 Developer Handover V18 — 24 October 2026
**Base:** Complete `MC5_Developer_Handover_v17.zip` (all original files retained unchanged).
**Additional authoritative review source:** `SOURCE_Master_Approved_Specification_20261023.docx` (uploaded Master record).
**Approved later changes:** `01_Approved_Changes_20261024.csv` and `04_AI_Drafting_Contract.md`.

## Authority / precedence
- Original approved Master Base Application and its approved 13 paragraphs + prayer text remain binding.
- Later user-approved corrections from both sample reviews override *only* the corresponding wording/layout rules, not unrelated prior approvals.
- V17 questionnaire/field IDs/crosswalk and audit materials are retained; 'candidate display text' in V17 is NOT verbatim approved.
- V14 Master Word Template is expressly REVIEW / NOT APPROVED; never replace the approved Master text with its illustrative text.
- Contradictions: log for review, do not resolve silently.

## Release gate — pending verification
1. Full screen-by-screen verbatim approved question text reconciled with V17 candidate labels.
2. Exact original approved land-table columns and layout confirmed in V17 Change Register and corresponding Word template; the simplistic sample table is not an approved replacement.
3. Every V18 change mapped to canonical field IDs and tested end-to-end with DOCX rendering.
4. Final prayer #2 implementation legal basis checked before public release (as Master flags).
5. Word signature/verification, enclosure list, and 3 obstruction-status cases acceptance tested.
**Status: Handover for developer implementation / review, not a production-ready legal filing generator.**
