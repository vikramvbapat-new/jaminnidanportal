# V18 AI Drafting Contract — कलम ५
**हा V17 चा addendum आहे; V17 मधील कोणताही स्रोत किंवा मंजूर निर्णय रद्द करत नाही.**

1. Input: फक्त user-verified structured facts. Output: paragraph-wise `number`, `text`, `source_field_ids`, `warnings`, `status`.
2. Paragraphs 1–13: विषय व क्रमांक अपरिवर्तनीय; अनुपयुक्त परिच्छेद वगळला तरी क्रमांक स्थिर.
3. Language: वादीची ठाम अर्जभाषा; mail merge नको; तृतीयपुरुषी `वादीचे म्हणणे आहे` नको; ५–६ अर्थपूर्ण वाक्ये शक्य तेव्हाच.
4. P01 अंतिम वाक्य अक्षरशः: **याच रस्त्यावरील अडथळा हा प्रस्तुत दाव्याचा विषय आहे.**
5. P02: पूर्वअस्तित्व व वापराची तथ्ये; पुरावे अजिबात नाहीत.
6. P03: वादीच्या शेतापासून बाहेरच्या दिशेने पुष्टी केलेल्या मार्गाने वर्णन. दिशेची माहिती अपुरी असल्यास पडताळणी मागावी. गाव रस्त्याशी जोडले असल्याची खात्री असेल तेव्हाच मंजूर वाक्य वापरावे: **अशा प्रकारे वादी यांच्या शेतजमिनीपासून गाव रस्त्यापर्यंत हा वहिवाटीचा रस्ता आहे.**
7. P10: फक्त उपलब्ध/निवडलेले पुरावे; संलग्न केले असल्याचे स्वतंत्र confirmation नसल्यास दावा नको.
8. P12: शीर्षक **दाव्यास कारण :**. एकच current actionable date; सामोपचारामुळे limitation reset नाही.
9. P09 व urgency prayer 4: तथ्ये व निवड पुष्टी झाल्यास दोन्ही. Status 3 मध्ये P09 वगळण्याचा Master नियम कायम.
10. P13: दावा दाखल तारीख व अडथळा तारीख तपासल्याशिवाय मुदतीतील दावा असल्याचे विधान नको.
11. Status 1/2: prayers 1,2,3; status 3: prayer 3 only; urgency असल्यास prayer 4; output मध्ये सलग क्रमांक.
12. No invented people, dates, locations, right-of-way entitlement, loss, evidence, respondents, directions, or damages.
13. Word layout order: Court → Case number → Plaintiffs → विरुद्ध → Defendants → Approved land-description table → §5 title → numbered body → prayers → enclosure list → signature/verification per approved template.
14. `श्री` नावापूर्वी नाही. Parties/gats repeatable.
15. Existing V14 Word template is marked REVIEW / NOT APPROVED. Do not treat it as final or silently use its divergent prayers or layout.
