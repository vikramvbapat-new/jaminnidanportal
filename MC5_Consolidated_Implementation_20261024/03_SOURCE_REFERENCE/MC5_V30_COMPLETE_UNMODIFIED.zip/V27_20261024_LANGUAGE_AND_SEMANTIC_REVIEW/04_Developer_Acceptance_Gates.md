# V27 — Controlled Drafting: language review and acceptance gates

**Nature:** Model-assisted editorial drafting carried out in this conversation and deterministic checks, using four wholly synthetic verified-input fixtures. **No live LLM API was connected or tested.** This is NOT a production AI generator.

## What is implemented
- Four authored context-sensitive Marathi drafts, with immutable paragraph subjects and numbers, exact deterministic prayers inherited from V26, approved land-table column count, distinct available-evidence vs attached-documents behavior.
- JSON paragraph candidates (`number/title/text/source_field_ids`), DOCX examples, and row-wise source trace.
- Reuse the V26 static validator for each candidate. Add a narrow extra guard for obvious unsupported quantitative claims, proof attachment allegations, improper limitation assertion, unverified mediation or final legal-right declaration.
- Four negative perturbation tests demonstrate why source IDs alone do not prove claim-level truth.

## Important limitations
1. Claim-to-source rows in `01_Fact_Clause_Audit.csv` are paragraph-level, **not** independently verified clause entailment.
2. V26's static validator may pass plausible-looking but false additions. V27 limited guard catches a few specific cases and is NOT a factual truth oracle. Require reviewer verification of every sentence; do not label this automatic semantic entailment validation.
3. V26 fixture has `MC5_ROUTE_DESTINATION` and `MC5_CONCRETE_DIFFICULTY`: these are QA-only auxiliary fields, not approved additional questionnaire questions.
4. S7 exact six option texts not all finalized, although individual reasons and visibility rules are documented in the change register. S02 urgent paragraph is draft-for-review, not a verbatim final frozen option.
5. S04_LATE: **BLOCK FINAL WORD**. Its QA DOCX intentionally includes a flagged unresolved time limitation and must never be released as court-ready.
6. Actual AI vendor integration, uploads/OCR, OTP, deletion controls, access/retention security, layout/verification, prayer 2 legal basis, and lawyer/human approval remain out of scope.

## Handover acceptance checklist
- [ ] Every drafted *clause* verified from a user-confirmed field and OCR verification audit.
- [ ] S7 six labels and all 47 field routings explicitly approved in Change Register; 13 paragraph numbers unchanged.
- [ ] Prayer 2 legal basis independently reviewed.
- [ ] Final DOCX signing/verification section layout and table approved.
- [ ] Real model produces at least three scenarios; test both hallucination and overly literal mail-merge effects.
- [ ] Final output blocked for unresolved dates, missing mandatory fields, or legal review flags.
- [ ] Full privacy/security regression (PII, logs, retention, OTP, authorization) run in intended environment.
