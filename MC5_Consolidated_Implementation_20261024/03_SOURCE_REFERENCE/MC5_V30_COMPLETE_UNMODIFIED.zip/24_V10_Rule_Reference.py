"""MC5 deterministic rule reference, NOT production petition generator.
Synthetic fixtures only. No case facts are inferred. No legal text generation.
"""
from datetime import date, timedelta

def evaluate(x):
    status=x.get("status")
    if status not in (1,2,3): raise ValueError("status must be 1,2,3")
    urgency=list(x.get("urgency",[]))
    allowed={1,2,3,4,5,6}
    if not set(urgency)<=allowed: raise ValueError("invalid urgency reason")
    excluded=[]
    if status==3 and urgency:
        excluded=urgency[:];urgency=[]
    if 2 in urgency and not x.get("standing_crop",False):
        urgency.remove(2);excluded.append(2)
    if 4 in urgency and not x.get("standing_crop",False):
        urgency.remove(4);excluded.append(4)
    if 3 in urgency and not x.get("harvest_suboptions"):
        urgency.remove(3);excluded.append(3)
    if 5 in urgency and not x.get("farmhouse_confirmed",False):
        urgency.remove(5);excluded.append(5)
    if 1 in urgency and x.get("crop_status") not in ("prevented","future"):
        urgency.remove(1);excluded.append(1)
    prayers=[3] if status==3 else [1,2,3]
    hearing=bool(urgency) and bool(x.get("urgent_hearing_opt_in",False))
    result={"prayers":prayers,"paragraph_9":bool(urgency),"effective_urgency":urgency,
            "excluded_urgency":sorted(excluded),"urgent_hearing":hearing,
            "annexures":[a for a in x.get("evidence",[]) if a.get("uploaded",False) and a.get("type")!="witness"],
            "length_mention":x.get("length_feet") is not None,
            "actual_crop_loss_statement":bool(x.get("actual_crop_loss_confirmed",False))}
    obstruction=x.get("obstruction_date"); filing=x.get("filing_date")
    if isinstance(obstruction,date) and isinstance(filing,date):
        # Six calendar months must be computed separately; conservative warning here.
        result["limitation"]="requires_calendar_month_validation"
        if filing<obstruction: result["limitation"]="invalid_date_order"
    else:result["limitation"]="date_unverified"
    return result
