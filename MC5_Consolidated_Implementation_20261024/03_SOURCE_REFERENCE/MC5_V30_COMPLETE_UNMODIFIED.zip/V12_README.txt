V12: field-to-13-paragraph crosswalk + four explicitly incomplete synthetic conditional Word proofs + structural checks. NOT FINAL. No real A–D facts inferred.
