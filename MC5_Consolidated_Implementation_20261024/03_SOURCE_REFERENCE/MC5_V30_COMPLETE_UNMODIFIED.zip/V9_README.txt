V9 adds source-supported A-D gap register, synthetic test fixtures, and review report. No A-D full Word regenerated; unverified facts not invented. V8 preserved.
