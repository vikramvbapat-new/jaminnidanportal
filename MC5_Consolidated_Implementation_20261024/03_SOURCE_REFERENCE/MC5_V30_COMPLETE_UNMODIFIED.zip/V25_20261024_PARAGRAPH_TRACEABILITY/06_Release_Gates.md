# V25 — प्रलंबित मुद्दे आणि स्वीकृती

## हा टप्पा पूर्ण
- १३ परिच्छेदांसाठी स्थिर विषय व source-field contract; ४७ IDs चा source-to-output impact map.
- V23/V24 संदर्भ-पाईपलाईनवर **सुधारित deterministic QA**; मूळ फायली बदलल्या नाहीत.
- स्वतंत्र सत्यापन: प्रत्येक छापलेल्या परिच्छेदासाठी अस्तित्वात असलेल्या field IDs चे provenance; opt-in, limitation, no invented damages आणि proof vs annexures नियम.
- चार synthetic Word नमुने आणि trace JSON.

## Production release BLOCKED
- **AI language engine नाही** — V25 मधील paragraph text नियमाधारित आहे, प्रत्यक्ष LLM quality test नाही.
- आधीच्या स्रोतांतील 28 UI questions/field labels च्या अंतिम शब्दांकनाची पडताळणी नाही; S7 सहा पर्याय प्रलंबित.
- P04 आणि P08 साठी वेगळी पुष्टी करणारे अधिकृत UI fields / प्रश्न असल्याचे पुरावे अपुरे. आम्ही नवीन प्रश्न मंजूर मानले नाहीत.
- `MC5_ROUTE_DESTINATION` / `MC5_CONCRETE_DIFFICULTY` हे QA-only auxiliary fields असून अंतिम प्रश्नावलीत मंजूर नाहीत.
- §5 मागणी २ ची कायदेशीर अंमलबजावणी पडताळायची आहे; अंतिम Word सत्यापन/स्वाक्षरी मजकूर मंजूर नाही.
- OCR, OTP, encrypted storage, 30-day physical deletion आणि पृष्ठ सुरक्षा यांच्या चाचण्या नाहीत.

## Release checks for developer
1. प्रश्नावली final freeze; each field has exact approved Marathi display wording + conditional rule.
2. प्रत्येक generated factual clause maps to verified source field(s); omit not-applicable without renumber.
3. Run genuine model generation on fixtures, human-review fluent Marathi, check no hallucination and no repetition.
4. Word generation visually QA tested against final approved court layout and both multi-party/multi-gat cases.
5. Security, privacy, retention, role and access controls independently tested.
