#!/usr/bin/env python3
# coding: utf-8
"""V25 source-controlled deterministic drafting QA runner.
NO live LLM, no new approved questions, NOT court-ready output.
Only verified fixture data is used. V23/V24 originals retained separately.
"""
from pathlib import Path
import sys
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'V23_20261024_REFERENCE_PIPELINE/reference'))
sys.path.insert(0,str(BASE/'V24_20261024_FIELD_INTEGRATION/reference'))
import mc5_reference as m
from v24_field_bridge import normalize,BridgeError

APPROVED_P1='याच रस्त्यावरील अडथळा हा प्रस्तुत दाव्याचा विषय आहे.'

def run(payload):
    data,alias=normalize(payload)
    out=m.compose(data)  # existing source, date and land validations
    f=data['fields'];status=f['MC5_CURRENT_STATUS']
    p={r['number']:r for r in out['paragraphs']}
    flags=[]
    # P01: clean unnecessary source reference; immutable approved ending.
    if 1 in p:
        p[1]['source_field_ids']=['MC5_VILLAGE','MC5_TALUKA','MC5_LAND_RECORDS']
        if not p[1]['text'].endswith(APPROVED_P1):raise m.InputError('P01 approved sentence absent')
    # P02: prior use only; evidence must remain P10.
    if 2 in p and any(x in p[2]['text'] for x in m.EVIDENCE.values()):
        raise m.InputError('P02 must not describe documentary evidence')
    # P04 is NOT a repetition slot. If no separate verified farming-usage fact,
    # omit P04 instead of repeating the same P02 sentence.
    if 4 in p:
        p.pop(4)
        flags.append({'paragraph':4,'reason':'Distinct pre-obstruction farming-use facts not captured in existing fixture; omit instead of repeat','action':'OMITTED (numbers unchanged)'})
    # P05: normalize approximate gat syntax, no invented exact claim.
    ob=f['MC5_OBSTRUCTION_GAT'];location=('अंदाजे गट क्रमांक ' if ob['certainty']=='approx' else 'गट क्रमांक ')+str(ob['number'])
    p[5]['text']=(f"प्रतिवादी यांनी दिनांक {m.fmt_date(f['MC5_OBSTRUCTION_DATE'])} रोजी मौजे {f['MC5_VILLAGE']} "
                  f"येथील {location} मधून जाणाऱ्या वादी यांच्या वापरातील रस्त्यावर अडथळा निर्माण केला.")
    # P07/P08: do not mechanically append suspicious '- अडचण आहे'.
    if 7 in p:
        effect=f.get('MC5_ACCESS_EFFECT','').strip().rstrip('.।')
        if status==3:
            p[7]['text']='अडथळ्याच्या काळात वादी यांच्या रस्त्याच्या वापरात अडचण निर्माण झाली होती.'
            p[7]['source_field_ids']=['MC5_CURRENT_STATUS']
            flags.append({'paragraph':7,'reason':'Exact past tense for former access impact not explicitly verified; avoid present-tense source quote','action':'DETAIL HELD FOR USER VERIFICATION'})
        else:p[7]['text']=effect+'; त्यामुळे वादी यांच्या शेतजमिनीकडे येण्या-जाण्यावर परिणाम होत आहे.'
    if 8 in p:
        detail=f.get('MC5_CONCRETE_DIFFICULTY','').strip().rstrip('.।')
        effect=f.get('MC5_ACCESS_EFFECT','').strip().rstrip('.।')
        if not detail or detail==effect:
            p.pop(8)
            flags.append({'paragraph':8,'reason':'No distinct confirmed hardship separate from P07','action':'OMITTED (numbers unchanged)'})
        elif status==3:
            p.pop(8)
            flags.append({'paragraph':8,'reason':'Confirmed historical tense needed for hardship detail in status 3','action':'OMITTED PENDING REVIEW'})
        else:
            p[8]['text']=detail+'.'
            p[8]['source_field_ids']=['MC5_CONCRETE_DIFFICULTY']
            if f.get('MC5_DAMAGE_ACTUAL') is True:
                flags.append({'paragraph':8,'reason':'Actual financial loss flag alone is insufficient to claim a specific loss','action':'DO NOT CLAIM AMOUNT/CAUSATION'})
    # P09: explicit opt-in needed; selected reason alone not a hearing request.
    if 9 in p:
        if status==3 or not f.get('MC5_URGENT_HEARING_OPTIN'):
            p.pop(9)
            flags.append({'paragraph':9,'reason':'Urgency hearing not explicitly opted in or status 3','action':'OMITTED'})
        else:
            flags.append({'paragraph':9,'reason':'Exact wording of six urgency choices pending formal approval','action':'REVIEW ONLY; no final UI wording frozen'})
    # Evidence labels are available proof only, never identify as attached unless confirmed separately.
    if 10 in p:p[10]['text']=p[10]['text'].replace('उपलब्ध असल्याचे वादी यांनी नमूद केले आहे.','उपलब्ध आहेत.')
    # P12: must not assume attempts extended limitation or claim post-obstruction date.
    p[12]['title']='दाव्यास कारण'
    # All output paragraphs ordered by immutable original number.
    out['paragraphs']=[p[k] for k in sorted(p)]
    out['trace_flags']=flags
    out['paragaph_mapping_rule']='Fixed P01–P13 labels; omitted topics do not renumber'
    out['source_audit']={'alias_bridge':alias,'source_field_ids':sorted(f),'drafting_mode':'DETERMINISTIC_QA_NOT_LIVE_AI','status':'REVIEW ONLY'}
    # Source integrity: provenance key must exist; QA extensions are visibly distinguished.
    for x in out['paragraphs']:
        if not x['source_field_ids']:raise m.InputError('Untraceable paragraph '+str(x['number']))
        missing=[key for key in x['source_field_ids'] if key not in f]
        # Certain prior V23 P03 optional fields are still emitted in provenance even if not supplied.
        if x['number']==3:
            x['source_field_ids']=[k for k in x['source_field_ids'] if k in f]
            missing=[]
        if missing:raise m.InputError('Missing provenance '+str(missing)+' in P'+str(x['number']))
    return data,out

def output(payload,docxpath,tracepath):
    import json
    data,out=run(payload)
    m.write_docx(data,out,docxpath)
    Path(tracepath).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    return out

if __name__=='__main__':
    import json
    f=Path(sys.argv[1]);dest=Path(sys.argv[2]);dest.mkdir(parents=True,exist_ok=True)
    output(json.loads(f.read_text(encoding='utf8')),str(dest/(f.stem+'_V25_QA.docx')),str(dest/(f.stem+'_V25_trace.json')))
