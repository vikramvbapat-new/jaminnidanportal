#!/usr/bin/env python3
# coding: utf-8
import sys,json,copy,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
sys.path.insert(0,str(BASE/'V23_20261024_REFERENCE_PIPELINE/reference'))
from v25_controlled_qa import run,APPROVED_P1
from mc5_reference import InputError
FIX=BASE/'V23_20261024_REFERENCE_PIPELINE/fixtures'
def load(n):return json.loads((FIX/(n+'.json')).read_text(encoding='utf8'))
class Regression(unittest.TestCase):
 def test_01_approved_P01(self):
  _,o=run(load('S01')); self.assertTrue(o['paragraphs'][0]['text'].endswith(APPROVED_P1))
 def test_02_P02_evidence_isolated(self):
  _,o=run(load('S02'));p={x['number']:x for x in o['paragraphs']};self.assertNotIn('जुने फोटो',p[2]['text']);self.assertIn('जुने फोटो',p[10]['text'])
 def test_03_P04_no_duplicate(self):
  _,o=run(load('S02'));self.assertNotIn(4,[x['number'] for x in o['paragraphs']]);self.assertIn(5,[x['number'] for x in o['paragraphs']])
 def test_04_no_forced_paragraph_8(self):
  z=load('S02');z['fields']['MC5_CONCRETE_DIFFICULTY']=z['fields']['MC5_ACCESS_EFFECT'];_,o=run(z);self.assertNotIn(8,[x['number'] for x in o['paragraphs']])
 def test_05_para8_distinct(self):
  _,o=run(load('S02'));p={x['number']:x for x in o['paragraphs']};self.assertIn(8,p);self.assertNotEqual(p[7]['text'],p[8]['text'])
 def test_06_status3_no_current_obstruction(self):
  _,o=run(load('S03'));p={x['number']:x for x in o['paragraphs']};self.assertNotIn('अडचण होत आहे',p.get(7,{}).get('text',''));self.assertNotIn(9,p)
 def test_07_status3_injunction_only(self):
  _,o=run(load('S03'));self.assertEqual([x['source_prayer_id'] for x in o['prayers']],[3])
 def test_08_consecutive_prayers(self):
  for k in ('S01','S02','S03'):
   _,o=run(load(k));self.assertEqual([x['display_number'] for x in o['prayers']],list(range(1,len(o['prayers'])+1)))
 def test_09_optin_required_for_P09(self):
  z=load('S02');z['fields']['MC5_URGENT_HEARING_OPTIN']=False;_,o=run(z);self.assertNotIn(9,[x['number'] for x in o['paragraphs']]);self.assertNotIn(4,[r['source_prayer_id'] for r in o['prayers']])
 def test_10_urgency_optin_generates_both(self):
  _,o=run(load('S02'));self.assertIn(9,[x['number'] for x in o['paragraphs']]);self.assertIn(4,[r['source_prayer_id'] for r in o['prayers']])
 def test_11_no_attached_docs_not_in_annexures(self):
  z=load('S02');z['attached_documents']=[];_,o=run(z);self.assertFalse(o['attachments'])
 def test_12_late_limitation_no_within_claim(self):
  _,o=run(load('S04_LATE'));p={x['number']:x for x in o['paragraphs']};self.assertTrue(o['warnings']);self.assertNotIn('विहित मुदतीत',p[13]['text'])
 def test_13_width_validation(self):
  z=load('S01');z['fields']['MC5_ROAD_WIDTH_FT']=0
  with self.assertRaises(InputError):run(z)
 def test_14_verified_land_sum(self):
  z=load('S01');z['fields']['MC5_LAND_RECORDS'][0]['source_total']=[9,99]
  with self.assertRaises(InputError):run(z)
 def test_15_date_forbidden_future_obstruction(self):
  z=load('S01');z['fields']['MC5_OBSTRUCTION_DATE']='2027-01-01'
  with self.assertRaises(ValueError):run(z)
 def test_16_incorrect_alias_conflict(self):
  z=load('S02');z['fields']['MC5_REASON4_DAMAGE']='actual'
  with self.assertRaises(ValueError):run(z)
 def test_17_missing_provenance(self):
  _,o=run(load('S02'));self.assertTrue(all(x['source_field_ids'] for x in o['paragraphs']))
 def test_18_P05_gat_syntax(self):
  z=load('S01');z['fields']['MC5_OBSTRUCTION_GAT']={'certainty':'approx','number':'१२४'};_,o=run(z);p={x['number']:x for x in o['paragraphs']};self.assertIn('अंदाजे गट क्रमांक १२४',p[5]['text'])
 def test_19_route_direction_only_confirmed(self):
  z=load('S02');z['fields'].pop('MC5_ROUTE_DESTINATION',None);_,o=run(z);p={x['number']:x for x in o['paragraphs']};self.assertNotIn('गाव रस्त्यापर्यंत',p[3]['text'])
 def test_20_no_blank_length_added(self):
  z=load('S02');z['fields'].pop('MC5_ROAD_LENGTH_FT',None);_,o=run(z);p={x['number']:x for x in o['paragraphs']};self.assertNotIn('लांबी',p[3]['text'])
 def test_21_13_titles_stable(self):
  _,o=run(load('S02'));nums=[x['number'] for x in o['paragraphs']];self.assertEqual(nums,sorted(nums));self.assertIn(12,nums);self.assertIn(13,nums)
 def test_22_no_fake_damages_risk(self):
  _,o=run(load('S02'));p={x['number']:x for x in o['paragraphs']};self.assertNotIn('पिकांचे प्रत्यक्ष नुकसान होत आहे',p[9]['text'])
 def test_23_p10_available_not_attached(self):
  _,o=run(load('S01'));p={x['number']:x for x in o['paragraphs']};self.assertNotIn('जोडलेली',p[10]['text'])
 def test_24_separate_section143_block(self):
  z=load('S01');z['fields']['MLRC143_OTHER']='NO'
  with self.assertRaises(ValueError):run(z)
if __name__=='__main__':unittest.main(verbosity=2)
