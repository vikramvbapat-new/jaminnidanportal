# MC5 V25 — Paragraph Traceability & Controlled Draft QA (24 October 2026)

Base: V24 ZIP; V17–V24 preserved **unchanged**. This V25 addition contains six documents and a runnable test/reference directory.

- `01_Immutable_Paragraph_Contract.json`: P01–P13 approved subjects & source fields, conditional status.
- `02_47_Field_to_Output_Effect.csv`: 47 IDs; which affect court text vs only account/system/consent/annexures.
- `03_Controlled_AI_Drafting_Prompt_Contract.md`: developer-ready bounded AI interface; not executed AI.
- `reference/v25_controlled_qa.py`: extends prior synthetic harness to reduce P02/P04 redundancy, ensure exact P01 closing, clean P05 approximate phrasing, separate P07/P08 and P09 opt-in.
- `reference/test_v25.py`: fresh runnable regression assertions.
- `output_examples/`: four synthetic draft DOCX and field provenance traces.
- `04_Test_Results.txt`, `05_QA_Scenario_Summary.json`, `06_Release_Gates.md`: transparent test evidence + residual blockers.

Execute after unzip: `python V25_20261024_PARAGRAPH_TRACEABILITY/reference/test_v25.py`.

**No production AI model has been executed. Generated DOCX files are QA-only and not approved pleadings.**
