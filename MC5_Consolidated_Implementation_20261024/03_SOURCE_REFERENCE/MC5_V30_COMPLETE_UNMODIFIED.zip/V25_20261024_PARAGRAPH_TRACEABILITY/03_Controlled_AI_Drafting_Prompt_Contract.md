# कलम ५ — Controlled AI Drafting Contract (V25 proposal, developer handoff)
**Inputs:** immutable approved MC5 legal-text bank; user-verified questionnaire facts; exact source field IDs; local date / filing date; obstruction status; selected evidence vs actually attached documents.
**Boundary:** no free-form legal advice, no external legal text or hallucinated evidence, no §143 fields, no invented road direction/ownership/tenure/damages. If an essential fact is missing, return a `blocking_error` or `needs_verification`, not a confident petition.

## Runtime contract (illustrative JSON fields)
```
{
  "module": "MC5", "master_version": "2026-10-23", "rule_version": "V25_REVIEW",
  "paragraphs": [{"paragraph_id": "P03", "number": 3, "approved_subject": "रस्त्याचा मार्ग व मोजमाप", "text": "...", "field_provenance": ["MC5_ROUTE_GATS","MC5_ROAD_WIDTH_FT"], "warnings": [], "approval_state": "QA_ONLY"}],
  "prayers": [{"approved_prayer_id": 3, "display_number": 1, "text": "..."}],
  "enclosures": [], "blocking_errors": [], "review_warnings": []
}
```

## Paragraph drafting priorities
1. **P01:** parties and land relationship from verified 7/12, exact approved closing line.
2. **P02:** confirmed old road use, not evidence types. **P03:** route starts at plaintiff's land; only add village road connection if explicitly confirmed; mandatory mean width feet; length optional.
3. **P04:** add *distinct* verified agricultural prior-use facts; otherwise omit while preserving later paragraph numbering.
4. **P05–P06:** one obstruction date, exact or approximate gat, type and present status. **P07/P08:** access effect vs distinct concrete hardship; no invented actual loss; status 3 historical tense only.
5. **P09:** only confirmed urgency and urgent hearing selection; exact S7 UI choice copy is still pending approval. **P10:** available evidence, not necessarily annexed.
6. **P11:** omit if no prior attempts; never imply mediation. **P12:** 'दाव्यास कारण' and single cause of action. **P13:** jurisdiction and checked limitation; no assertion if not checked/late.
7. Prayers from Master only, status-specific, consecutive display numbering; #2 legal basis remains release gate. No interim road-opening relief.

## Source-grounding / QA gates
- Each factual clause must be entailed by cited field ID(s), not merely attached to a generic paragraph-level reference.
- Keep `field_provenance` and clause-level evidence mapping in audit logs; never expose internal AI directives in final Word.
- No forced word count, no empty filler, no detached `वादीचे म्हणणे आहे`; natural Marathi legal pleading.
- Do not call V25 deterministic renderer an LLM evaluation. Independent review of actual model outputs, human-approved Marathi language, security/retention, and legal review are required before deployment.

## Unresolved approvals
- 28 fields / screen wording status in V24, including exact six S7 urgency choice texts.
- Proposed aliases; OCR storage/retention and OTP implementation; Word signature/verification text.
- QA-only auxiliary fields `MC5_ROUTE_DESTINATION`, `MC5_CONCRETE_DIFFICULTY` must be approved/formalized before a final schema freeze.
