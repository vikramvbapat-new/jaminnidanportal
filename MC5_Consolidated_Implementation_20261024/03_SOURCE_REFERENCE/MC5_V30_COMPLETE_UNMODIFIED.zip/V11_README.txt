V11: Four synthetic Word proof documents, 20 executable checks, report. No actual case facts generated. V10 files preserved.
