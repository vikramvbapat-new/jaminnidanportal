# Executable QA reference (NOT production AI)

Install: `pip install python-docx python-dateutil`.
Run: `python mc5_reference.py ../fixtures/S01.json ../output_examples/S01_trace.json ../output_examples/S01_preview.docx`
Tests: `python -m unittest -v test_reference.py` (run from reference folder).

## Explicit limitations
1. Deterministic *template-based* reference, not controlled AI paragraph expansion; no live web, OCR, OTP, storage, UI, APIs, voice-to-text, Word versioning or full role management.
2. All fixture persons, locations, areas, dates, facts and evidence are **fictional**; fixture flag `confirmed` means acceptance-test condition only and MUST NOT suggest real verification.
3. Non-V17 field `MC5_ROUTE_DESTINATION` and `MC5_CONCRETE_DIFFICULTY` are **QA-only extensions** for traceable, confirmed narrative input; no authorization to add these UI fields without approval.
4. Static labels for six urgency reasons are sourced to Change Register V17 (around paragraphs 98–105) but *final verbatim approval pending*. Do not deploy as final UI.
5. Three status choices must be displayed with full, exactly approved text. Reference code uses status ID for branching and does not implement real UI.
6. The legal validity of prayer #2, the actual limitation computation, court jurisdiction, and Word signature/verification layout still require legal and user sign-off.
7. The tool accepts a synthetic JSON payload with full structured facts; it is not a real form submission.
8. No generated example is for filing in court.
