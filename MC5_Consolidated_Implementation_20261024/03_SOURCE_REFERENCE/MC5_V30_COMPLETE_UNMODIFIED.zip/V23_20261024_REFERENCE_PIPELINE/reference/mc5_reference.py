#!/usr/bin/env python3
# coding: utf-8
"""MC5 v23 deterministic reference flow: structured fixture -> checked factual paragraphs -> Word.
This is NOT an AI engine, not legal counsel, not production deployment.
Data schema is a QA harness, not an approved UI questionnaire or final API schema.
"""
from pathlib import Path
from datetime import date
from decimal import Decimal
import json, sys, re
from dateutil.relativedelta import relativedelta
from docx import Document
from docx.shared import Cm, Pt

STATUS = {1:"अडथळा पूर्वीप्रमाणेच कायम आहे.",2:"अडथळा काही प्रमाणात दूर झाला आहे; परंतु रस्त्याच्या वापरात अजूनही अडचण आहे.",3:"भौतिक अडथळा दूर झाला आहे; परंतु भविष्यात पुन्हा अडथळा निर्माण होऊ नये म्हणून मनाई आदेशाची मागणी करावयाची आहे."}
EVIDENCE = {1:"रस्ता दर्शविणारा नकाशा",2:"महसूल/न्यायालयीन आदेश",3:"रस्त्याचा उल्लेख असलेले नोंदणीकृत दस्त",4:"शासकीय योजनेतील रस्त्याचा दस्तऐवज",5:"जुने फोटो",6:"साक्षीदार",7:"इतर"}
ATTEMPTS={1:"प्रतिवादींना वैयक्तिक विनंती",2:"गावातील प्रतिष्ठित व्यक्ती/मध्यस्थांमार्फत प्रयत्न",3:"ग्रामपंचायत/तंटामुक्ती/महसूल अधिकाऱ्यांकडे प्रयत्न",4:"पोलिस तक्रार"}
RESPONSES={1:"प्रतिवादी यांनी अडथळा दूर करण्यास नकार दिला",2:"प्रतिवादी यांनी आश्वासन दिले; मात्र त्याचे पालन केले नाही",3:"प्रतिवादी यांनी अडथळा तात्पुरता दूर केला आणि पुन्हा निर्माण केला",4:"प्रतिवादी यांनी प्रतिसाद दिला नाही"}
# Six urgency labels appear in V17 Change Register, but the register expressly flags their
# final verbatim wording as PENDING. Here the ID is the authoritative branch, text is REVIEW ONLY.
URGENCY={1:"पेरणी किंवा लागवडीचा हंगाम संपत चालल्याने वेळेत पीक घेता येणार नाही",2:"उभ्या पिकांची मशागत, खते देणे किंवा निगा राखणे वेळेत करता येत नाही",3:"पीक काढणी किंवा शेतमालाची वाहतूक वेळेत करता येत नाही",4:"पिकांचे नुकसान होत आहे किंवा वेळेत शेतीकामे न झाल्यास नुकसान होण्याची शक्यता आहे",5:"शेतातील घराकडे जाण्या-येण्यास अडचण निर्माण झाली आहे",6:"शेतीच्या इतर आवश्यक कामांमध्ये विलंब होत असल्याने तातडीने रस्ता वापरणे आवश्यक आहे"}
REASON3={1:"पीक काढणीसाठी आवश्यक यंत्रसामग्री किंवा वाहने शेतात नेता येत नाहीत",2:"काढलेला शेतमाल शेतातून बाहेर नेता येत नाही",3:"भाजीपाला, फुले किंवा इतर पिकांची नियमित किंवा वारंवार काढणी व वाहतूक करण्यात अडचण येत आहे",4:"पीक काढणीसाठी आवश्यक मजूर किंवा इतर साधनसामग्री ने-आण करण्यात अडचण येत आहे"}
PRAYERS={1:"वादी यांच्या पूर्वीपासूनच्या वापरातील व दाव्यात वर्णन केलेल्या रस्त्यावर प्रतिवादी यांनी निर्माण केलेला अडथळा दूर करण्याचे आदेश देण्यात यावेत.",2:"प्रतिवादी यांनी अडथळा दूर न केल्यास सदर अडथळा सक्षम अधिकाऱ्यामार्फत दूर करून रस्ता पूर्वीप्रमाणे खुला करून मिळावा.",3:"प्रतिवादी यांनी वादी यांच्या सदर रस्त्याच्या वापरास भविष्यात कोणत्याही प्रकारे अडथळा निर्माण करू नये, असा मनाई आदेश देण्यात यावा.",4:"वादी यांना सदर रस्त्याच्या वापराची तातडीची आवश्यकता असल्याने प्रस्तुत प्रकरणाची तातडीने सुनावणी घेऊन अंतिम निर्णय देण्यात यावा."}
TITLES={1:"जमिनींचा संबंध",2:"रस्त्याचे पूर्वअस्तित्व",3:"रस्त्याचा मार्ग व मोजमाप",4:"शेती व रस्त्याचा पूर्वीचा वापर",5:"अडथळ्याची तारीख व ठिकाण",6:"अडथळ्याचे स्वरूप व सद्यस्थिती",7:"रस्त्याच्या वापरावरील परिणाम",8:"अडचणी व नुकसान",9:"तातडीची कारणे",10:"रस्त्याच्या अस्तित्वाचे पुरावे",11:"पूर्वीचे प्रयत्न व प्रतिसाद",12:"दाव्यास कारण",13:"अधिकारक्षेत्र व मुदत"}

class InputError(ValueError):pass

def require(cond,msg):
 if not cond:raise InputError(msg)

def deva(v):return str(v).translate(str.maketrans('0123456789','०१२३४५६७८९'))

def fmt_date(s):return deva(date.fromisoformat(s).strftime('%d-%m-%Y'))

def dnum(x):
 d=Decimal(str(x));require(d>0 and d.is_finite(),'Width/length must be positive')
 return f'{d.normalize():f}'

def area_for(row):
 # Strict source 7/12 area: h + are; keep cultivable, potkharab and source total apart
 for field in ('cultivable','potkharab','source_total'):
  require(field in row and len(row[field])==2,f'Land {field} missing')
  h,a=row[field];require(type(h)==int and type(a)==int and h>=0 and 0<=a<=99,f'Land {field} components invalid')
 h,a=row['assessment'];require(type(h)==int and type(a)==int and h>=0 and 0<=a<=99,'Assessment invalid')
 cv=row['cultivable'][0]*100+row['cultivable'][1]
 pk=row['potkharab'][0]*100+row['potkharab'][1]
 tot=row['source_total'][0]*100+row['source_total'][1]
 require(cv+pk==tot,'7/12 total mismatch — block use in Word; do not change source total')
 return {'area':f"लागवडीलायक: {row['cultivable'][0]}.{row['cultivable'][1]:02d}\nपोटखराब: {row['potkharab'][0]}.{row['potkharab'][1]:02d}", 'assessment':f'{h}.{a:02d}', 'part':row['part'],'village':row['village'],'gat':str(row['gat'])}

def validate(data):
 f=data['fields'];must=['MC5_VILLAGE','MC5_TALUKA','MC5_PLAINTIFFS','MC5_DEFENDANTS','MC5_LAND_RECORDS','MC5_ROUTE_GATS','MC5_ROAD_WIDTH_FT','MC5_PREEXISTING_USE','MC5_OBSTRUCTION_DATE','MC5_OBSTRUCTION_GAT','MC5_OBSTRUCTOR_ROLE','MC5_OBSTRUCTION_TYPES','MC5_CURRENT_STATUS','MC5_ATTEMPTS_MADE','MC5_FILING_DATE','MC5_REVIEW_CONSENT']
 for k in must:require(k in f,f'Missing {k}')
 for k in ('MC5_VILLAGE','MC5_TALUKA'):require(isinstance(f[k],str) and f[k].strip(),f'{k} missing')
 for k in ('MC5_PLAINTIFFS','MC5_DEFENDANTS'):
  require(isinstance(f[k],list) and f[k],f'{k} empty')
  require(all(x.get('name') and x.get('confirmed') is True for x in f[k]),f'Unverified party in {k}')
 require(isinstance(f['MC5_LAND_RECORDS'],list) and f['MC5_LAND_RECORDS'],'Land records empty')
 for record in f['MC5_LAND_RECORDS']:
  require(record.get('verified') is True,'Unverified 7/12 data')
  area_for(record)
 require(len(f['MC5_ROUTE_GATS'])>0,'Empty road gats')
 require(isinstance(f['MC5_PREEXISTING_USE'],str) and f['MC5_PREEXISTING_USE'].strip(),'Preexisting use missing')
 dnum(f['MC5_ROAD_WIDTH_FT'])
 if f.get('MC5_ROAD_LENGTH_FT') not in (None,''):dnum(f['MC5_ROAD_LENGTH_FT'])
 require(f['MC5_OBSTRUCTOR_ROLE'] in (1,2),'Invalid obstructor role')
 require(isinstance(f['MC5_OBSTRUCTION_TYPES'],list) and all(isinstance(x,str) and x.strip() for x in f['MC5_OBSTRUCTION_TYPES']) and f['MC5_OBSTRUCTION_TYPES'],'Missing obstruction form')
 require(f['MC5_CURRENT_STATUS'] in (1,2,3),'Invalid obstruction status')
 gat=f['MC5_OBSTRUCTION_GAT'];require(isinstance(gat,dict) and gat.get('certainty') in ('exact','approx') and str(gat.get('number','')).strip(),'Missing confirmed/approx obstruction gat')
 o=date.fromisoformat(f['MC5_OBSTRUCTION_DATE']); filing=date.fromisoformat(f['MC5_FILING_DATE']);require(o<=filing,'Obstruction date after filing')
 require(f['MC5_REVIEW_CONSENT'] is True,'Final consent missing')
 if f['MC5_ATTEMPTS_MADE']:
  require(f.get('MC5_ATTEMPT_TYPES') and f.get('MC5_DEFENDANT_RESPONSE') in RESPONSES,'Attempt response missing')
 else:
  require(not f.get('MC5_ATTEMPT_TYPES') and not f.get('MC5_DEFENDANT_RESPONSE'),'Hidden attempt responses must be cleared')
 if f.get('MC5_CURRENT_STATUS')==3:
  require(not f.get('MC5_URGENCY_REASONS') and not f.get('MC5_URGENT_HEARING_OPTIN'),'Status 3 must clear present urgency')
 reasons=f.get('MC5_URGENCY_REASONS',[])
 require(all(r in URGENCY for r in reasons),'Unsupported urgency ID')
 if reasons:
  require(f.get('MC5_CURRENT_STATUS') in (1,2),'Urgency not applicable')
  crop=f.get('MC5_CROP_STATUS')
  if 1 in reasons:require(crop in ('not_grown','no_current_planned'),'Reason 1 not eligible')
  if 2 in reasons:require(crop=='standing','Reason 2 not eligible')
  if 3 in reasons:
   require(crop=='standing' or f.get('MC5_HARVESTED_STOCK') is True,'Reason 3 not eligible')
   require(f.get('MC5_URGENCY_3_SUBOPTIONS') and all(x in REASON3 for x in f['MC5_URGENCY_3_SUBOPTIONS']),'Reason 3 must have confirmed suboptions')
  if 4 in reasons:require(f.get('MC5_URGENCY_4_DAMAGE_STATUS') in ('actual','risk'),'Reason 4 needs actual/risk')
  if 5 in reasons:require(f.get('MC5_FARM_HOUSE_CONFIRMED') is True,'Reason 5 needs house confirmation')
 require(not f.get('MC5_URGENT_HEARING_OPTIN') or bool(reasons),'Urgent hearing needs confirmed urgency')
 # Annexures are not evidence file uploads; only checked actual enclosures.
 attached=data.get('attached_documents',[])
 require(all(isinstance(x,dict) and x.get('actually_attached') is True and x.get('label') for x in attached),'Annexure falsely shown attached')
 warnings=[]
 sixmonths=o+relativedelta(months=6)
 if filing>=sixmonths:warnings.append('मर्यादेबाबत गंभीर सूचना: सहा महिन्यांच्या सीमेवर किंवा पुढे; वकिलांच्या सल्ल्याशिवाय दावा दाखल करू नये.')
 elif filing>=sixmonths-relativedelta(days=30):warnings.append('सहा महिन्यांची मर्यादा जवळ आहे; दाखल करण्याची तारीख वकिलांकडून पडताळावी.')
 return warnings,filing<sixmonths

def compose(data):
 warnings,within=validate(data);f=data['fields'];paragraphs=[]
 def add(n,text,sources):paragraphs.append({'number':n,'title':TITLES[n],'text':text,'source_field_ids':sources})
 village=f['MC5_VILLAGE'];taluka=f['MC5_TALUKA'];gat=f['MC5_OBSTRUCTION_GAT'];obstr_gat=('अंदाजे ' if gat['certainty']=='approx' else '')+str(gat['number'])
 plaint_gats=[str(x['gat']) for x in f['MC5_LAND_RECORDS'] if x['part']=='वादी'];def_gats=[str(x['gat']) for x in f['MC5_LAND_RECORDS'] if x['part']=='प्रतिवादी']
 add(1, f'वादी यांची शेतजमीन मौजे {village}, तालुका {taluka} येथील गट क्रमांक {", ".join(plaint_gats)} मध्ये आहे. प्रतिवादी यांच्या शेतजमिनीचा तपशील वरील तक्त्यात आहे. याच रस्त्यावरील अडथळा हा प्रस्तुत दाव्याचा विषय आहे.', ['MC5_VILLAGE','MC5_TALUKA','MC5_LAND_RECORDS','MC5_OBSTRUCTION_GAT'])
 add(2,f"अडथळा निर्माण होण्यापूर्वी सदर रस्ता अस्तित्वात होता. {f['MC5_PREEXISTING_USE'].strip().rstrip('.।')}.",['MC5_PREEXISTING_USE'])
 r=' → '.join(str(x) for x in f['MC5_ROUTE_GATS']);direction=f.get('MC5_ROUTE_DESTINATION')
 st=f'वादी यांच्या मौजे {village} येथील शेतजमिनीपासून {r} या पुष्टी झालेल्या मार्गाने सदर वादग्रस्त रस्ता जातो.'
 if direction=='गाव रस्ता':st+=' अशा प्रकारे वादी यांच्या शेतजमिनीपासून गाव रस्त्यापर्यंत हा वहिवाटीचा रस्ता आहे.'
 st+=f" सदर वादग्रस्त रस्त्याची अंदाजे सरासरी रुंदी {dnum(f['MC5_ROAD_WIDTH_FT'])} फूट आहे."
 if f.get('MC5_ROAD_LENGTH_FT') not in (None,''):st+=f" अंदाजे लांबी {dnum(f['MC5_ROAD_LENGTH_FT'])} फूट आहे."
 add(3,st,['MC5_VILLAGE','MC5_ROUTE_GATS','MC5_ROUTE_DESTINATION','MC5_ROAD_WIDTH_FT','MC5_ROAD_LENGTH_FT'])
 add(4,f"शेतीसंबंधी पूर्वीच्या वापराची पुष्टी झालेली वस्तुस्थिती अशी आहे : {f['MC5_PREEXISTING_USE'].strip().rstrip('.।')}.",['MC5_PREEXISTING_USE'])
 add(5,f"प्रतिवादी यांनी दिनांक {fmt_date(f['MC5_OBSTRUCTION_DATE'])} रोजी मौजे {village} येथे {obstr_gat} गट क्रमांकातील रस्त्यावर अडथळा निर्माण केला.",['MC5_OBSTRUCTION_DATE','MC5_VILLAGE','MC5_OBSTRUCTION_GAT'])
 types=' व '.join(f['MC5_OBSTRUCTION_TYPES'])
 status=f['MC5_CURRENT_STATUS']
 if status==1:t6=f'प्रतिवादी यांनी सदर रस्त्यावर {types} असा अडथळा निर्माण केला असून तो पूर्वीप्रमाणेच कायम आहे.'
 elif status==2:t6=f'प्रतिवादी यांनी सदर रस्त्यावर {types} असा अडथळा निर्माण केला होता. तो काही प्रमाणात दूर झाला असला तरी रस्त्याच्या वापरात अजूनही अडचण आहे.'
 else:t6=f'प्रतिवादी यांनी सदर रस्त्यावर {types} असा अडथळा निर्माण केला होता. सद्यस्थितीत भौतिक अडथळा पूर्णपणे दूर झाला आहे.'
 add(6,t6,['MC5_OBSTRUCTION_TYPES','MC5_CURRENT_STATUS'])
 if f.get('MC5_ACCESS_EFFECT'):
  effect=f['MC5_ACCESS_EFFECT'].strip().rstrip('.।')
  if status==3:effect+=' (अडथळ्याच्या काळातील पूर्वस्थिती)'
  else:effect+=' अशी अडचण आहे'
  add(7,effect+'.',['MC5_ACCESS_EFFECT','MC5_CURRENT_STATUS'])
 if f.get('MC5_CONCRETE_DIFFICULTY'):
  difficulty=f['MC5_CONCRETE_DIFFICULTY'].strip().rstrip('.।')
  if status==3:difficulty+=' (अडथळ्याच्या काळातील पूर्वस्थिती)'
  else:difficulty+=' अशी अडचण होत आहे'
  add(8,difficulty+'.',['MC5_CONCRETE_DIFFICULTY','MC5_CURRENT_STATUS'])
 reasons=f.get('MC5_URGENCY_REASONS') or []
 if reasons:
  lines=[]
  for id in reasons:
   if id==3:lines.extend(REASON3[x] for x in f['MC5_URGENCY_3_SUBOPTIONS'])
   elif id==4:
    if f['MC5_URGENCY_4_DAMAGE_STATUS']=='actual':lines.append('पिकांचे प्रत्यक्ष नुकसान होत असल्याची पुष्टी करण्यात आली आहे')
    else:lines.append('वेळेत शेतीकामे न झाल्यास पिकांचे नुकसान होण्याची शक्यता आहे')
   else:lines.append(URGENCY[id])
  add(9,'; '.join(lines)+'.',['MC5_URGENCY_REASONS']+(['MC5_URGENCY_3_SUBOPTIONS'] if 3 in reasons else [])+(['MC5_URGENCY_4_DAMAGE_STATUS'] if 4 in reasons else []))
 evid=f.get('MC5_EVIDENCE_TYPES') or []
 if evid:add(10,'सदर रस्त्याचे पूर्वअस्तित्व व वहिवाट यासंबंधी वादी यांच्याकडे '+', '.join(EVIDENCE[i] for i in evid)+' उपलब्ध असल्याचे वादी यांनी नमूद केले आहे.',['MC5_EVIDENCE_TYPES'])
 if f['MC5_ATTEMPTS_MADE']:
  at=', '.join(ATTEMPTS[i] for i in f['MC5_ATTEMPT_TYPES'])
  add(11,f'सदर अडथळा दूर करण्यासाठी वादी यांनी {at} केले. {RESPONSES[f["MC5_DEFENDANT_RESPONSE"]]}.',['MC5_ATTEMPTS_MADE','MC5_ATTEMPT_TYPES','MC5_DEFENDANT_RESPONSE'])
 cause=f"प्रतिवादी यांनी दिनांक {fmt_date(f['MC5_OBSTRUCTION_DATE'])} रोजी रस्त्यावर अडथळा निर्माण केल्यामुळे प्रस्तुत दाव्यास कारण उत्पन्न झाले आहे."
 add(12,cause,['MC5_OBSTRUCTION_DATE'])
 jur=f'वादग्रस्त रस्ता व अडथळ्याचे ठिकाण मौजे {village}, तालुका {taluka} येथे असल्याने प्रस्तुत दावा चालविण्याचे अधिकारक्षेत्र मा. मामलेदार न्यायालय, {taluka} यांना आहे.'
 if within:jur+=' तसेच प्रतिवादी यांनी सदर रस्त्यावर अडथळा निर्माण केल्यापासून विहित मुदतीत प्रस्तुत दावा दाखल करण्यात येत आहे.'
 add(13,jur,['MC5_VILLAGE','MC5_TALUKA','MC5_OBSTRUCTION_DATE','MC5_FILING_DATE'])
 prayer_ids=[1,2,3] if status in (1,2) else [3]
 if reasons and f.get('MC5_URGENT_HEARING_OPTIN'):prayer_ids.append(4)
 return {'paragraphs':paragraphs,'prayers':[{'source_prayer_id':n,'display_number':i+1,'text':PRAYERS[n]} for i,n in enumerate(prayer_ids)],'warnings':warnings,'land_rows':[area_for(r) for r in f['MC5_LAND_RECORDS']],'attachments':[r['label'] for r in data.get('attached_documents',[])],'status':status,'source_version':'V17 Master + V18 approved delta; QA reference implementation only'}

def write_docx(data,assembled,path):
 f=data['fields'];d=Document();sec=d.sections[0];sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8);sec.left_margin=Cm(2);sec.right_margin=Cm(2)
 sty=d.styles['Normal'];sty.font.name='Noto Sans Devanagari';sty.font.size=Pt(10)
 d.add_heading('कृत्रिम चाचणी माहिती — न्यायालयात दाखल करू नये',level=1)
 d.add_paragraph(f"मा. मामलेदार न्यायालय, {f['MC5_TALUKA']}")
 d.add_paragraph('दावा क्रमांक : ____ / '+deva(f['MC5_FILING_DATE'][:4]))
 d.add_paragraph('वादी : '+', '.join(r['name'] for r in f['MC5_PLAINTIFFS']))
 d.add_paragraph('विरुद्ध')
 d.add_paragraph('प्रतिवादी : '+', '.join(r['name'] for r in f['MC5_DEFENDANTS']))
 table=d.add_table(rows=1,cols=5);table.style='Table Grid'
 for cell,val in zip(table.rows[0].cells,['पक्षकार','गाव','गट क्रमांक/सर्वे क्रमांक','क्षेत्र (हे. आर.)','आकार (₹)']):cell.text=val
 for r in assembled['land_rows']:
  for c,val in zip(table.add_row().cells,[r['part'],r['village'],r['gat'],r['area'],r['assessment']]):c.text=val
 d.add_paragraph('मामलेदार न्यायालय अधिनियम, १९०६ चे कलम ५ अन्वये रस्त्यावरील अडथळा दूर करण्याबाबत दावा',style='Heading 2')
 for r in assembled['paragraphs']:
  d.add_paragraph(f"{deva(r['number'])}) {r['title']} :",style='Heading 3');d.add_paragraph(r['text'])
 d.add_paragraph('तरी विनंती की,')
 for r in assembled['prayers']:d.add_paragraph(f"{deva(r['display_number'])}) {r['text']}")
 if assembled['attachments']:
  d.add_paragraph('जोडपत्रे :')
  for i,x in enumerate(assembled['attachments'],1):d.add_paragraph(f'{deva(i)}) {x}')
 d.add_paragraph('वादीची स्वाक्षरी : _______________')
 d.add_paragraph('दिनांक : '+fmt_date(f['MC5_FILING_DATE']))
 if assembled['warnings']:
  d.add_paragraph('तपासणी सूचना (विकासक QA) :')
  for w in assembled['warnings']:d.add_paragraph(w)
 Path(path).parent.mkdir(parents=True,exist_ok=True)
 d.save(path)

if __name__=='__main__':
 payload=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
 result=compose(payload)
 Path(sys.argv[2]).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 write_docx(payload,result,sys.argv[3])
