from pathlib import Path
import sys,json,unittest,copy
sys.path.insert(0,str(Path(__file__).parent))
from mc5_reference import validate,compose,InputError,write_docx
F=Path(__file__).resolve().parents[1]/'fixtures'
def load(x):return json.loads((F/(x+'.json')).read_text(encoding='utf-8'))
class QA(unittest.TestCase):
 def test_cases(self):
  for n in (1,2,3):
   with self.subTest(status=n):
    c=compose(load(f'S0{n}'))
    self.assertEqual([r['source_prayer_id'] for r in c['prayers']],[1,2,3] if n<3 else [3]) if n!=2 else self.assertEqual([r['source_prayer_id'] for r in c['prayers']],[1,2,3,4])
    self.assertEqual([r['display_number'] for r in c['prayers']],list(range(1,len(c['prayers'])+1)))
    self.assertEqual([r['number'] for r in c['paragraphs'] if r['number']==12],[12])
    self.assertTrue(all(r['source_field_ids'] for r in c['paragraphs']))
 def test_removed_status_no_current_urgency(self):
  c=compose(load('S03'));self.assertNotIn(9,[p['number'] for p in c['paragraphs']]);self.assertNotIn(1,[p['source_prayer_id'] for p in c['prayers']]);self.assertNotIn(2,[p['source_prayer_id'] for p in c['prayers']])
 def test_missed_limitation(self):
  c=compose(load('S04_LATE'));self.assertTrue(c['warnings']);self.assertNotIn('विहित मुदतीत',next(p['text'] for p in c['paragraphs'] if p['number']==13))
 def test_no_use_without_verified(self):
  x=load('S01');x['fields']['MC5_LAND_RECORDS'][0]['verified']=False
  with self.assertRaises(InputError):compose(x)
 def test_area_mismatch_block(self):
  x=load('S01');x['fields']['MC5_LAND_RECORDS'][0]['source_total']=[1,21]
  with self.assertRaises(InputError):compose(x)
 def test_no_fabricated_length(self):
  x=load('S01');x['fields']['MC5_ROAD_LENGTH_FT']=None
  self.assertNotIn('लांबी',next(p['text'] for p in compose(x)['paragraphs'] if p['number']==3))
 def test_no_unconfirmed_public_connection(self):
  x=load('S01');x['fields']['MC5_ROUTE_DESTINATION']=None
  self.assertNotIn('गाव रस्त्यापर्यंत',next(p['text'] for p in compose(x)['paragraphs'] if p['number']==3))
 def test_optional_omit_does_not_renumber(self):
  x=load('S01');x['fields']['MC5_ATTEMPTS_MADE']=False;x['fields']['MC5_ATTEMPT_TYPES']=[];x['fields']['MC5_DEFENDANT_RESPONSE']=None
  p=compose(x)['paragraphs'];self.assertNotIn(11,[r['number'] for r in p]);self.assertEqual(next(r['number'] for r in p if r['title']=='दाव्यास कारण'),12)
 def test_unattached_not_annexed(self):
  x=load('S01');x['attached_documents']=[];self.assertFalse(compose(x)['attachments'])
 def test_urgency_reason4_not_actual_damage(self):
  c=compose(load('S02'));p9=next(p['text'] for p in c['paragraphs'] if p['number']==9)
  self.assertIn('शक्यता',p9);self.assertNotIn('प्रत्यक्ष नुकसान होत',p9)
 def test_hidden_status_urgency_blocked(self):
  x=load('S03');x['fields']['MC5_URGENCY_REASONS']=[1]
  with self.assertRaises(InputError):compose(x)
 def test_consent_required(self):
  x=load('S01');x['fields']['MC5_REVIEW_CONSENT']=False
  with self.assertRaises(InputError):compose(x)
 def test_road_width_required(self):
  x=load('S01');x['fields']['MC5_ROAD_WIDTH_FT']=0
  with self.assertRaises(InputError):compose(x)
 def test_no_fabricated_attached_evidence(self):
  x=load('S01');x['attached_documents']=[{'label':'गावनकाशा','actually_attached':False}]
  with self.assertRaises(InputError):compose(x)
 def test_reason3_subchoices_and_crop(self):
  x=load('S01');x['fields']['MC5_URGENCY_REASONS']=[3]
  with self.assertRaises(InputError):compose(x)
  x['fields']['MC5_URGENCY_3_SUBOPTIONS']=[2];self.assertIn('शेतमाल',next(p['text'] for p in compose(x)['paragraphs'] if p['number']==9))
 def test_exact_approx_obstruction_gat(self):
  x=load('S01');x['fields']['MC5_OBSTRUCTION_GAT']['certainty']='approx'
  self.assertIn('अंदाजे',next(p['text'] for p in compose(x)['paragraphs'] if p['number']==5))
 def test_no_unconfirmed_party(self):
  x=load('S01');x['fields']['MC5_PLAINTIFFS'][0]['confirmed']=False
  with self.assertRaises(InputError):compose(x)
if __name__=='__main__':unittest.main(verbosity=2)
