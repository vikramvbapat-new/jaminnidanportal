# V29 — Developer Release Order (source based)

## Freeze already approved (do NOT reopen)
1. §5 separate from §143, 13 stable topics/numbers, status-based prayers.
2. V17 five-column 7/12 land table and independent OCR user verification.
3. S7: all later-approved conditional logic for 3/4/5/6, S7 optional, hidden for status 3. Suboptions V12, V8, V14 exact.
4. V17 registration/OTP, save draft, distinct users, case expiry 30 days from first start; portal app serial ≠ court case number.
5. P01, P02, P03, P12 later narrow sample corrections from V18.

## Minimal human decisions remaining
A. Confirm verbatim UI labels for S7 causes 1, 2 and 3 as recorded in V11; review overall S7 complete screen, not six broad legal choices again.
B. Decide whether urgent-hearing prayer #4 needs independent opt-in (V15 historical unresolved), then change change register and UI test.
C. Approve exact final screen question text where V16 says proposed/missing, distinguishing *registration/system/alias* fields from true user-facing prompts.
D. Approve canonical alias mapping and final Word layout (signature/verification/annexures), using actual rendered sample.
E. Independent legal verification for prayer #2, late/boundary limitation and filing warnings.

## Developer-only implementation (approval not substitute)
F. Secure live AI adapter, structured JSON, source facts snapshot, paragraph validators, human review per revision.
G. OTP/account, OCR, encryption and access control; retention deletion and audit.
H. Mobile QA, 3 obstruction statuses, adverse/blank cases, visual Word regression and final user acceptance.

## Evidence hierarchy
Explicit *later approval on the same subject* supersedes earlier pending/proposal. Source-derived rule is not the same as source-approved *exact UI words*. For any conflict, register a review issue rather than silently modify a frozen paragraph or prayer.

## Shipping status
V29 = source reconciled handover and approvals register. No live AI/OCR/OTP, independent legal determination, or user signoff. Do not market it as production-ready or a finished legal generator.
