import json,csv,sys
from pathlib import Path
from docx import Document
root=Path(__file__).resolve().parent
s=json.loads((root/'02_S7_Consolidated_Source_Rules.json').read_text(encoding='utf8'))
d=Document(root.parent/'SOURCE_Master_Change_Register_V17.docx')
text='\n'.join(p.text.strip() for p in d.paragraphs)
results=[]
def check(k,cond,detail):results.append({'test':k,'passed':bool(cond),'detail':detail})
check('S7-reason-count',len(s['reasons'])==6,'Six source-listed reasons')
for r in s['reasons']:
 check(r['id']+'-label-source',r['label'].rstrip(' .') in text,'Wording occurs in V17 Change Register')
check('S7-3-four-suboptions',len(s['reasons'][2]['suboptions'])==4 and all(x.rstrip(' .') in text for x in s['reasons'][2]['suboptions']),'Four reason-3 options grounded in V12')
check('S7-4-two-suboptions',len(s['reasons'][3]['suboptions'])==2 and all(x.rstrip(' .') in text for x in s['reasons'][3]['suboptions']),'Two reason-4 damage states grounded in V8')
check('S7-5-confirm',s['reasons'][4]['subquestion'].rstrip(' .') in text,'Reason-5 yes/no confirmation grounded in V14')
check('S7-6-no-five', 'पाच अतिरिक्त उपप्रश्न पूर्णतः रद्द' in text and len(s['reasons'][5]['suboptions'])==0,'Reason-6 no follow-up question')
check('S7-optional','तातडीची कारणे ऐच्छिक' in text,'Optional urgency V15')
check('S7-fully-removed','वर्तमानकालीन तातडीचे प्रश्न लपव' in text,'All present urgency hidden when obstruction removed')
check('P13-late-warning','Word तयार करण्यास बंदी नाही' in text,'V6 late-case drafting explicit')
check('S7-prayer4-open','स्वतंत्र पुष्टीने जोडायची की स्वयंचलितपणे' in text,'V15 prayer 4 question recorded pending')
check('30-day-original-start','प्रश्नावली प्रथम सुरू केल्याच्या वेळेपासून' in text,'V17 original 30-day clock')
out={'count':len(results),'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] for x in results),'tests':results,'type':'source static audit only; no runtime or AI provider exercised'}
(root/'07_Source_Only_Executed_Tests.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(f"V29 SOURCE AUDIT: {out['passed']}/{out['count']} passed")
for x in results:
 if not x['passed']:print('FAIL',x)
if out['failed']:sys.exit(1)
