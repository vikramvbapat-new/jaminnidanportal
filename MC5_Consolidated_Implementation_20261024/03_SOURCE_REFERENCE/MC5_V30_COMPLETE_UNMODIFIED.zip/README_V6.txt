V6 adds source A-D sample cases, original working language bank, consistency audit, and a source-based QA review. This is NOT final developer release.
