MC5 V4 — Supplement to V3. Includes 07 approved-text controls, 08 traceability matrix, 09 additional tests, 10 quality gate. This is NOT final developer signoff. The V3 base files remain unchanged.
