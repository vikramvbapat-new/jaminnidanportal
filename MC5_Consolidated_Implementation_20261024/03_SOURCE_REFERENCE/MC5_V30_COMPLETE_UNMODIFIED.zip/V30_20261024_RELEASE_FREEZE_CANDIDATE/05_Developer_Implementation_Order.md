# MC5 V30 — Developer Implementation Freeze Candidate

## Authority precedence
1. Original user-approved 13-topic Master Base Application, immutable numbering and prayers.
2. Later **explicit** approvals on precisely the same issue (V18 P01/P03/P12 corrections; S7 V9–V15 decisions) override only that issue.
3. V29 source reconciliation (not new user approval).
4. Candidate V30 field text/alias mappings remain unsigned until separately approved.

## Execution order
1. Freeze source contract, retain original source docs and SHA256.
2. Reviewer verifies only outstanding S7-1/2/3 labels; do NOT reopen the approved S7 suboptions and visibility logic.
3. Freeze all other *visible* question strings per screen. Registration, system and alias fields are NOT automatically 47 visible questions.
4. Obtain explicit PR4 decision: proposed separate yes/no confirmation; never infer yes from an urgency checkbox until approval.
5. Sign off aliases with conflict detection; do not rename existing persisted data silently.
6. Render 3 obstruction statuses + six-month review-only sample; compare table, prayers, labels, signature and annexures to Master.
7. Independently confirm the legal implementation of PR-2 and the treatment of late cases. Preserve approved wording pending review.
8. Build live AI adapter / OCR / OTP / user-based access / 30-day purge, then run integration, security, and UX tests.

## Release gate and fail-closed rules
- No invented people, gats, dates, damages, road connection, or evidence.
- No 'within limitation' assertion without validated obstruction/filing dates; any expired claim triggers a clear review notice.
- Source doc allows producing a warning-marked review Word in late cases; such review Word MUST NOT be labeled filing-ready.
- Only case-specific verified facts may go to paragraph text. Persist source-field trace per paragraph.
- PR-4 automatic insertion is NOT approved; the independent opt-in is a conservative candidate until the user signs.
- P13 and S7 status=3 cannot imply continuing physical obstruction.
- Module §143 must not leak into §5 field IDs, document title, or respondent terms.

Status: pre-approval developer handover; not a live AI API, not production-ready.
