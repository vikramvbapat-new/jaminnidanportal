# V22 — Implementation handoff boundary
This version is an **executable static source/Word audit**, not a real questionnaire → AI → Word engine.

## Canonical input
- Keep original 47 IDs unchanged until user approves V17 *proposed* canonical aliases.
- Do not interpret `V20 proposed route` as approved display wording.
- If question text is missing or status says not verbatim approved, block release of that screen.
- `paragraph_target_V4` is legacy routing metadata, not proof that actual AI text used that source.
- For every generated paragraph require `paragraph_no`, `source_field_ids`, `verified_facts`, `text`, `warnings`.
- Render final Word only after required width, road route, obstruction gat, dates, parties, land table and attachment selections are verified.
- Status 3: only injunction prayer, no continuing physical obstruction.
- Optional paragraphs may be omitted; retain original immutable numbering.

## Hard blockers
1. 27 fields not explicitly included in V17 crosswalk (some account/system; classify and approve mapping).
2. Approved exact screen wording not established for every field, including six S7 urgency options.
3. Sample Word files contain intentionally unverified placeholders, so they are NOT final petitions.
4. No AI drafting API/runtime or UI implementation included.
5. Prayer #2 legal implementation basis and final layout require signoff.

## Acceptance gate
Run actual end-to-end scenarios with fixed verified fixtures and inspect DOCX renders; compare paragraphs and prayer selection against approved Master. Do not call static proof checks end-to-end tests.
