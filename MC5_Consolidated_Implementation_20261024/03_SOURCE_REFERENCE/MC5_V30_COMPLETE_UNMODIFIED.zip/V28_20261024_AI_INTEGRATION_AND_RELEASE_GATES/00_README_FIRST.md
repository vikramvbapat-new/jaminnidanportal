# जमीन निदान पोर्टल V2 — कलम ५ — V28 Developer Handover
**Date:** 24 October 2026  |  **Base:** full V27 archive retained without overwriting approved sources.

## What is actually delivered

1. `reference/integration_reference.py`: executed provider-neutral **replay-only** reference orchestration. It does not connect to an AI service. Real model calls are deliberately blocked.
2. `contracts/01_AI_Provider_Integration_Contract.md`: developer contract for secure AI service connection, versioning, error handling and trust boundary.
3. `contracts/02_Draft_Approval_State_Machine.md`: independent human/fact/legal/operational gates before final issuance.
4. `contracts/03_Model_Only_Paragraphs_Response.schema.json`: proposed JSON schema for what a future provider may return (only paragraphs, never prayer text or land descriptions).
5. `tests/test_integration_reference.py`: runnable negative and regression unit tests.
6. `results/test_run.txt`, `results/V28_Test_Summary.json`: actual results from replay fixtures.
7. `results/S01_Release_Gates_Example.json`: practical example of approval statuses and why production release remains blocked.
8. `03_Open_Gates_And_Developer_Backlog.csv`: blocking vs subsequent tasks.

## V28 distinction: draft vs Word release

**Draft generation:** A future model only proposes paragraphs; paragraph numbering, subjects, source IDs and actual content are independently verified. Prayers, attachments, five-column land table, obstruction status are calculated deterministically in software, not chosen by model.

**Human review:** Every drafted paragraph must be compared to actually verified facts, and Marathi language reviewed. The reviewer approves an exact candidate, facts snapshot, rule version and revision. Any changes invalidate the attestation.

**Release:** The reference implementation **will NEVER release a court-ready Word petition**, even after a synthetic reviewer approves it. The project lacks live model testing, actual user authentication, finished Word production service, approved complete S7 wording, legal verification of prayer #2, and privacy/security QA. Synthetic QA previews are separately marked “न्यायालयात दाखल करू नये”.

## Key non-negotiable decisions preserved

- Immutable 13 paragraph subjects/numbers and conditional omissions; sequentially numbered applicable prayers.
- P01 approved final sentence; P02 prior-use facts but no evidence; P03 plaintiff-land-first direction only with verified destination; P12 exact heading.
- Three approved obstruction statuses; optional P09 and urgent prayer only under approved confirmation; no interim opening in main petition.
- All 7/12 OCR-derived parties and lands verified by user; available evidence is distinct from actually attached annexures.
- No §143 legal wording in §5 module. No made-up facts, damages, rights, dates, directions or persons.

## Factual limitation

A static validator can confirm that a paragraph has a source ID but **cannot** establish that its every assertion is true. V28 blocks some obvious fabricated claims but requires human *clause-level* fact checking for every real AI draft. The test provider replays V27 manually authored synthetic Marathi candidates, **not** outputs from any API.

## Run tests

From unpacked ZIP root:

```bash
python V28_20261024_AI_INTEGRATION_AND_RELEASE_GATES/tests/test_integration_reference.py
```

Python test deps: `python-docx`, `python-dateutil` (already used by V23–V27). This package is a developer reference, not hosted software.
