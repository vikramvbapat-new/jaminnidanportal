# V28 — Provider-neutral controlled-AI integration contract

**Status:** developer implementation proposal; no production provider or credentials configured. The code supplied with V28 uses `ReplayProvider` only.

## 1. Who owns each decision?

| Stage | Allowed responsibility | Explicitly forbidden |
|---|---|---|
| Mobile UI | Gather verified structured answers and required confirmation | Unapproved extra question text and automatic assumptions from OCR |
| Backend | Freeze input revision, validate mandatory facts, enforce field aliases, role and status gates | Sending unconfirmed 7/12 OCR content as established facts |
| AI provider | Suggest idiomatic Marathi prose for P01–P13, with source IDs, strictly within approved facts | Editing prayers, replacing five-column land table, creating dates/people/damages, determining court jurisdiction beyond verified facts, inventing a legal entitlement |
| Deterministic assembler | Immutable paragraph headings/numbers, original Master prayer text and conditional selection, attachments, table and dates | Rewriting a prayer with generated text |
| Validator | Static structural/source checks, limitation warning, narrow extra hallucination guards | Asserting that every natural-language clause is true |
| Reviewer | Check every factual clause against verified inputs; Marathi quality; relevant legal checks | Delegating truth verification to the model without review |
| Export service | Validate authenticated final consent, exact reviewed revision, prior gates, successfully generate Word, allocate number atomically | Publishing a filing-ready petition from this reference test code |

## 2. Input envelope (proposed API contract, not V17-approved UI wording)

```json
{
  "module": "MC5",
  "master_version": "MC5_MASTER_2026-10-23_PLUS_APPROVED_2026-10-24_DELTA",
  "ruleset_version": "MC5_V28_REVIEW_CONTRACT_DRAFT",
  "draft_id": "opaque-server-id",
  "revision": 3,
  "verified_facts": {"MC5_ROAD_WIDTH_FT": 8},
  "permitted_output": ["paragraphs", "needs_verification", "blocking_errors"]
}
```

Before calling an actual model, the backend must validate the full approved field schema and filter out source document instructions. In V28 reference the sample provider reads the existing verified fixture; raw OCR images, photos, PDFs and source files **must not be sent** by default. Enforce data minimization: forward only the facts needed for each paragraph, not unrelated account fields or uploads.

The trusted instruction and the field values must remain separate. User data, OCR snippets and document content are untrusted *data* even when later verified; instructions embedded in them do not override the application-side drafting rules. Consider output size limits, timeout, structured JSON parsing and a retry cap.

## 3. Output and assembly

Model response **only**:

```json
{
  "paragraphs": [
    {
      "number": 3,
      "title": "रस्त्याचा मार्ग व मोजमाप",
      "text": "...",
      "source_field_ids": ["MC5_ROUTE_GATS", "MC5_ROAD_WIDTH_FT"]
    }
  ],
  "needs_verification": [],
  "blocking_errors": []
}
```

The software must deterministically append Master-verbatim `prayers`, verified five-column `land_rows`, actual `attachments` and actual `status`. Any provider attempt to include these derived/final fields is rejected as an integration-contract violation. Always fail closed on unknown paragraph IDs, wrong titles, placeholder text, cross-module terminology, unsupported claims, missing source IDs or stale source revision.

## 4. Request, state and retries

1. `draft_input_revision` is created only after all OCR recommendations have been explicitly confirmed or edited and mandatory route/width/date questions answered.
2. Backend creates `request_hash` over verified input + ruleset + module + draft ID + revision. It cannot rely on the model to sign or attest to this hash.
3. Backend calls the model with provider-specific credentials stored only on the server, never in mobile client or DOCX metadata.
4. A `draft_candidate` is written to a *pending review* store and checked, without allocating a final petition/application serial.
5. If validation fails: return coded error(s); require user correction or re-generation with explicit revision; do not repair inventively.
6. After human review, bind attestation to **candidate hash, ruleset, exact fact revision** and independently authenticated reviewer/user IDs.
7. Any field edit, OCR correction, attachment choice change, model regeneration or substantive draft edit **invalidates** review and final consent. The new candidate must be checked again.
8. Final export is a separate backend operation; require authentication, role checks, independent legal and operational quality gates, atomic numbering and safe Word rendering before declaring completion. Idempotent repeat request must not allocate a second serial.

## 5. API and privacy/security measures to implement

- Strong authentication + short-lived sessions; separate user/reviewer/developer authorizations and tenant isolation.
- Protect user data in transit and at rest; provider API secrets held in a server-side vault. No names, 7/12 text, prompts or case paragraphs in general logs.
- Server-generated idempotency key, optimistic revision locking, transactional application-number allocation and audit timestamps.
- Audit: draft ID, revision, ruleset, success/failure codes, review version, timestamps, retention events; do not log case content by default.
- Provider privacy and data-retention agreement must be validated before uploading actual client facts; distinguish actual server-side retention from the previously approved **30-day portal lifecycle policy**. The code does not implement deletion.
- Malicious prompt injection, unusually large output, invalid JSON, refusal, hallucinated facts, rate limiting, timeout and service failures must produce controlled, user-understandable retry/review states.
- Store source-to-paragraph mapping and, for each claimed factual clause, a reviewer-verifiable evidence path. Do not treat source-field labels as proof of truth.
- Use signed checksum/versioned template bundle to prevent unauthorized changes to immutable Master prayer or word text.
- No official website release until exact approved S7 wording, all field IDs, Word layout and prayer #2 legal basis are verified.

## 6. Failure code guidance

- `INPUT_INVALID`, `UNVERIFIED_OCR`, `FIELD_ALIAS_CONFLICT`, `FILING_DATE_REVIEW_REQUIRED`
- `POSSIBLE_PROMPT_INJECTION`, `MODEL_INVALID_SCHEMA`, `MODEL_PRIVILEGE_ESCALATION`
- `MODEL_REQUESTS_VERIFICATION`, `P02_EVIDENCE`, `P03_UNVERIFIED_DESTINATION`, `FALSE_ANNEXURE`
- `CLAUSE_REVIEW_INCOMPLETE`, `STALE_ATTESTATION`, `FACTS_CHANGED_AFTER_APPROVAL`
- `WORD_LAYOUT_NOT_APPROVED`, `S7_WORDING_NOT_FROZEN`, `PRAYER2_LEGAL_PENDING`
- `PROVIDER_TIMEOUT`, `MODEL_UNAVAILABLE`, `PERSISTENCE_FAILURE`, `RELEASE_BLOCKED`

Codes not exercised by V28 tests are *design targets*, not implemented outcomes.
