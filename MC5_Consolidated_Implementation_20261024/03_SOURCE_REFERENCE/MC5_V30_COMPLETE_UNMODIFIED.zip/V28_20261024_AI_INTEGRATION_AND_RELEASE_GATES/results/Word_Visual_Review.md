# V28 S01 synthetic Word — visual QA record

- Rendered with `/home/oai/skills/docx/render_docx.py` on 24 October 2026.
- Page count: 2.
- Both generated PNG pages visually inspected.
- All five land table columns, Marathi headings, numbered paragraphs, prayers, annexures and signature line are present and legible.
- No obvious clipping, font missing-glyph substitution, unexpected blank pages, or table cutoff in this synthetic sample.
- QA banner on first page explicitly says **“कृत्रिम चाचणी माहिती — न्यायालयात दाखल करू नये”**.
- Not approved as final user-facing legal Word layout. Some Marathi phrases still require editing; signature/verification and multi-party large-document pagination were not certified.
- Synthetic QA review was simulated programmatically, not authenticated human approval.
